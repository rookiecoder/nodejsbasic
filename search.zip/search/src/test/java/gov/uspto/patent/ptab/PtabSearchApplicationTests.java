package gov.uspto.patent.ptab;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PtabSearchApplicationTests {

	@Test
	void contextLoads() {
	}

}
