package gov.uspto.patent.ptab.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import gov.uspto.patent.ptab.model.ESDocMetaDataEntity;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.search.SearchHits;

import java.util.*;

public class JSonUtil {
    static ObjectMapper objectMapper = new ObjectMapper();

    public static List<ESDocMetaDataEntity> transformResponse(String responseBody) throws JsonProcessingException {
        List<ESDocMetaDataEntity> documents = new ArrayList<>();
        JsonNode actualObj = objectMapper.readTree(responseBody);
        JsonNode hitParents = actualObj.get("hits");
        JsonNode hitsArrays = hitParents.get("hits");
        if (hitsArrays.isArray()) {
            for (JsonNode hitObject : hitsArrays) {
                ESDocMetaDataEntity dataDocument = objectMapper.convertValue(hitObject.get("_source"), ESDocMetaDataEntity.class);
                documents.add(dataDocument);
            }
        }
        return documents;
    }

    public static List<ESDocMetaDataEntity> transformResponse(SearchResponse searchResponse) throws JsonProcessingException {
        SearchHits hits = searchResponse.getHits();
        List<ESDocMetaDataEntity> documents = new ArrayList<>();
        Arrays.stream(hits.getHits()).forEach(hit -> {
            String source = hit.getSourceAsString();
            ESDocMetaDataEntity document = null;
            try {
                document = objectMapper.readValue(source, ESDocMetaDataEntity.class);
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
            documents.add(document);
        });
        return documents;
    }

    public static String convert(ESDocMetaDataEntity data) throws JsonProcessingException {
        return objectMapper.writeValueAsString(data);
    }

    public static String getJsonPropertyvalue(String json) throws JsonProcessingException {
        return objectMapper.readTree(json).get("query").toString();
    }

    public static String removeAliases(String json,Map<String, String> keys) throws JsonProcessingException {
        JsonNode parent = objectMapper.readTree(json);
        System.out.println(objectMapper.writeValueAsString(parent));
        for (Map.Entry<String,String> key : keys.entrySet()) {
            List<JsonNode> children = parent.findParents(key.getKey());
            if(children == null || children.size()==0){
                continue   ;
            }

            for(JsonNode child : children){
                ((ObjectNode) child).put(key.getValue(), child.get(key.getKey()));
                ((ObjectNode) child).remove(key.getKey());
                System.out.printf("Key %s exists? %s --> value=%s%n", key, child != null,
                        child == null ? null : key.getKey());
            }


        }
        return objectMapper.writeValueAsString(parent);
    }
}
