package gov.uspto.patent.ptab.config.textextract;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ResourceLoader;
import org.springframework.http.converter.StringHttpMessageConverter;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.jdbc.datasource.lookup.DataSourceLookupFailureException;
import org.springframework.jdbc.datasource.lookup.JndiDataSourceLookup;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.client.RestTemplate;

import javax.sql.DataSource;
import java.nio.charset.StandardCharsets;

/**
 * This class is used to configure database parameters and set ORM entities and SQL XML files into localSessionFactoryBean
 *
 * @author 2020 Development Team
 */
@Slf4j
@Configuration
@EnableTransactionManagement
@EnableCaching
public class DataBaseConfiguration {

    private static final String HIBERNATE_CACHE_INFINISPAN_STATISTICS = "hibernate.cache.infinispan.statistics";
    private static final String HIBERNATE_CACHE_USE_QUERY_CACHE = "hibernate.cache.use_query_cache";
    private static final String HIBERNATE_CACHE_REGION_FACTORY_CLASS = "hibernate.cache.region.factory_class";
    private static final String HIBERNATE_CACHE_USE_SECOND_LEVEL_CACHE = "hibernate.cache.use_second_level_cache";
    private static final String HIBERNATE_SHOW_SQL = "hibernate.show_sql";
    private static final String HIBERNATE_DIALECT = "hibernate.dialect";
    private static final String PTAB_DATASOURCES = "java:jboss/datasources/PTABTRIALS";

    @Autowired
    private ResourceLoader resourceLoader;

    @Value("${hbm.files.path}")
    private String hbmFilesPath;

    @Value("${hibernate.cache.use_second_level_cache}")
    private String useSecondLevelCache;

    @Value("${hibernate.cache.region.factory_class}")
    private String factoryClass;

    @Value("${hibernate.cache.use_query_cache}")
    private String useQueryCache;

    @Value("${hibernate.cache.infinispan.statistics}")
    private String infinispanStatistics;

    @Value("${spring.datasource.driver-class-name}")
    private String driverName;

    @Value("${spring.datasource.url}")
    private String dataSourceUrl;

    @Value("${spring.datasource.username}")
    private String userName;

    @Value("${spring.datasource.password}")
    private String password;

    @Value("${hibernate.dialect}")
    private String dialect;

    @Value("${hibernate.show_sql}")
    private String showSql;

    @Value("${entitymanager.packagesToScan}")
    private String packagesToScan;

    /**
     * Data source configuration. Externalize into properties file.
     *
     */
    //@Bean
    public DataSource dataSource() {
        DataSource dataSource;
        try {
             final JndiDataSourceLookup dataSourceLookup = new JndiDataSourceLookup();
            dataSource = dataSourceLookup.getDataSource(PTAB_DATASOURCES);
        } catch (final DataSourceLookupFailureException e) {
            log.error("DataSourceLookupFailure ", e);
            final DriverManagerDataSource localDataSource = new DriverManagerDataSource();
            localDataSource.setDriverClassName(driverName);
            localDataSource.setUrl(dataSourceUrl);
            localDataSource.setUsername(userName);
            localDataSource.setPassword(password);
            dataSource = localDataSource;
        }
        return dataSource;

    }


    /**
     * Initializes RestTemplate bean
     * 
     * @return
     */
    @Bean
    public RestTemplate getRestTemplate() {
        final RestTemplate restTemplate = new RestTemplate();
        restTemplate.getMessageConverters().add(0, new StringHttpMessageConverter(StandardCharsets.UTF_8));
        return restTemplate;
    }
}
