package gov.uspto.patent.ptab.service.es;

import com.fasterxml.jackson.core.JsonProcessingException;
import gov.uspto.patent.ptab.config.MappingConfig;

import gov.uspto.patent.ptab.model.ESDocMetaDataEntity;
import gov.uspto.patent.ptab.utils.JSonUtil;
import lombok.extern.slf4j.Slf4j;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.*;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.List;

@Service
@Slf4j
public class ESDocumentService {

    @Value("${es.index}")
    private String esIndex;

    @Autowired
    private MappingConfig mappingConfig;

    @Autowired
    @Qualifier("elasticsearchClient")
    RestHighLevelClient restHighLevelClient;

    public List<ESDocMetaDataEntity> searchQuery(String searchQuery) throws IOException {
        String query = JSonUtil.getJsonPropertyvalue(JSonUtil.removeAliases(searchQuery,mappingConfig.getMappings()).replaceAll("[\\n\\t ]", ""));
        System.out.println(query);
        QueryBuilder builder = QueryBuilders.wrapperQuery(query);
        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        searchSourceBuilder.query(builder);
        SearchRequest searchRequest = new SearchRequest(esIndex);
        searchRequest.source(searchSourceBuilder);
        SearchResponse searchResponse = restHighLevelClient.search(searchRequest, RequestOptions.DEFAULT);
        return JSonUtil.transformResponse(searchResponse);
    }

    public List<ESDocMetaDataEntity> searchAndQuery() throws IOException {
        //and
        BoolQueryBuilder first = QueryBuilders.boolQuery()
                .must(QueryBuilders.matchQuery("city", "menlo park"))
                .must(QueryBuilders.matchQuery("country", "us"));
        BoolQueryBuilder filter = new BoolQueryBuilder()
                .should(first);

        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        searchSourceBuilder.query(filter);
        SearchRequest searchRequest = new SearchRequest(esIndex);
        searchRequest.source(searchSourceBuilder);
        SearchResponse searchResponse = restHighLevelClient.search(searchRequest, RequestOptions.DEFAULT);
        return JSonUtil.transformResponse(searchResponse);
    }

    public List<ESDocMetaDataEntity> searchORQuery() throws IOException {
        //or
        BoolQueryBuilder first = QueryBuilders.boolQuery()
                .must(QueryBuilders.matchQuery("city", "menlo park"));
        BoolQueryBuilder second = QueryBuilders.boolQuery()
                .must(QueryBuilders.matchQuery("country", "us"));
        BoolQueryBuilder filter = new BoolQueryBuilder()
                .should(first)
                .should(second);

        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        searchSourceBuilder.query(filter);
        SearchRequest searchRequest = new SearchRequest(esIndex);
        searchRequest.source(searchSourceBuilder);
        SearchResponse searchResponse = restHighLevelClient.search(searchRequest, RequestOptions.DEFAULT);
        return JSonUtil.transformResponse(searchResponse);
    }

    public ESDocMetaDataEntity create(ESDocMetaDataEntity payload) throws IOException {
        String json = JSonUtil.convert(payload);
        final IndexRequest indexRequest = new IndexRequest(esIndex,esIndex)
                .source(json, XContentType.JSON);
        IndexResponse response = restHighLevelClient.index(indexRequest,RequestOptions.DEFAULT);
        return payload;
    }

    public List<ESDocMetaDataEntity> bulkInsert(List<ESDocMetaDataEntity> payload) throws IOException {
        BulkRequest bulkRequest = new BulkRequest();

        payload.forEach(item -> {
            IndexRequest indexRequest = null;
            try {
                indexRequest = new IndexRequest(esIndex,esIndex).
                        source(JSonUtil.convert(item), XContentType.JSON);
            } catch (JsonProcessingException e) {
                log.error(e.getMessage(), e);
            }

            bulkRequest.add(indexRequest);
        });

        try {
            restHighLevelClient.bulk(bulkRequest, RequestOptions.DEFAULT);
        } catch (IOException e) {
            log.error(e.getMessage(), e);
        }
        return payload;
    }
}
