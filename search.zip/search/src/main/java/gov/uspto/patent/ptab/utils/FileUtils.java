package gov.uspto.patent.ptab.utils;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;

public class FileUtils {

    public static byte[] readFileContent(String filePath) throws IOException {
        return Files.readAllBytes(Paths.get(filePath));
    }

    public static byte[] readFileContent(File file) throws IOException {
        return Files.readAllBytes(file.toPath());
    }
}
