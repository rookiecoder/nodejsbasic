package gov.uspto.patent.ptab.config.textextract;

import java.io.IOException;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.IntStream;

import org.springframework.batch.core.ExitStatus;
import org.springframework.batch.core.StepContribution;
import org.springframework.batch.core.StepExecution;
import org.springframework.batch.core.StepExecutionListener;
import org.springframework.batch.core.scope.context.ChunkContext;
import org.springframework.batch.core.step.tasklet.Tasklet;
import org.springframework.batch.repeat.RepeatStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import gov.uspto.patent.ptab.model.CmsDocId;
import gov.uspto.patent.ptab.model.DocMetaDataEntity;
import gov.uspto.patent.ptab.repository.CmsDocumentLoadRepository;
import gov.uspto.patent.ptab.repository.DocMetaDataRepository;
import gov.uspto.patent.ptab.service.textextract.IngestService;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class TextExtractProcessor implements Tasklet, StepExecutionListener {

    @Autowired
    IngestService ingestService;

    //@Autowired
    DocMetaDataRepository docMetaDataRepository;

    //@Autowired
    CmsDocumentLoadRepository cmsDocumentLoadRepository;

    @Autowired
    ResourcePatternResolver resoursePatternResolver;

    @Value("${textextract.input.location}")
    String fileLocation;

    @Value("${textextract.source.location}")
    String sourceLocation;

    @Value("${textextract.page.size}")
    int pageSize;

    @Value("${textextract.output.location}")
    String outputLocation;

    Resource[] resources;

    @Override
    public void beforeStep(StepExecution stepExecution) {
        try {
            resources = resoursePatternResolver.getResources(sourceLocation + "/**/*.*");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @Override
    public ExitStatus afterStep(StepExecution stepExecution) {
        return null;
    }

    @Override
    public RepeatStatus execute(StepContribution contribution, ChunkContext chunkContext)  {
        int dbcount = docMetaDataRepository.getQueuedDocumentCount();
        log.info("Total document count "+dbcount);
        int totalPasses = (dbcount/(pageSize)) + 1;
        IntStream.iterate(0, start -> start + 1)
            .limit(totalPasses)
            .forEach(start -> {
                log.debug("page number is "+ start);
                processDocuments(start);
            });

        return null;
    }

    private void processDocuments(int page)  {
        List<BigDecimal> artifactIds = new ArrayList<>();
        Pageable pageable = PageRequest.of(page, pageSize);
        Page<DocMetaDataEntity> metaDataEntities = docMetaDataRepository.getCompletedDocumentInformation(pageable);
        log.info("Retrieving page "+page + " "+metaDataEntities.stream().count() + " "+metaDataEntities.getTotalElements());
       try {
            for (DocMetaDataEntity element : metaDataEntities.getContent()) {
                 ingestService.ingest(element);
                 artifactIds.add(element.getProceedingArtifactId());
            }
            //TODO - bulk update status after processing records in a page
           ingestService.updateSearchIndexingStatus(artifactIds);
        }
        catch (Exception e) {
            log.error("Exception occured creating output JSON" +e.getMessage());
            e.printStackTrace();
        }
    }
}
