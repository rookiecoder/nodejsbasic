package gov.uspto.patent.ptab.controller;

import gov.uspto.patent.ptab.config.MappingConfig;
import gov.uspto.patent.ptab.model.ESDocMetaDataEntity;
import gov.uspto.patent.ptab.service.es.ESDocumentService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;
import java.util.Map;

@RestController
@Slf4j
@RequestMapping("/ptab/search")
public class SearchController {

    @Autowired
    ESDocumentService service;

    @Autowired
    private MappingConfig mappingConfig;

    @PostMapping(value = "/search", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<ESDocMetaDataEntity>> documentSearch(@RequestBody String payload) throws IOException {
        return new ResponseEntity<List<ESDocMetaDataEntity>>(service.searchQuery(payload), HttpStatus.OK);
    }

    @GetMapping(value = "/searchAndQuery", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<ESDocMetaDataEntity>> documentAndSearch() throws IOException {
        return new ResponseEntity<List<ESDocMetaDataEntity>>(service.searchAndQuery(), HttpStatus.OK);
    }

    @GetMapping(value = "/searchOrQuery", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<ESDocMetaDataEntity>> documentOrSearch() throws IOException {
        return new ResponseEntity<List<ESDocMetaDataEntity>>(service.searchORQuery(), HttpStatus.OK);
    }

    @PostMapping(value = "/create", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ESDocMetaDataEntity> create(@RequestBody ESDocMetaDataEntity payload) throws IOException {
        return new ResponseEntity<ESDocMetaDataEntity>(service.create(payload), HttpStatus.OK);
    }

    @PostMapping(value = "/bulk", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<ESDocMetaDataEntity>> create(@RequestBody List<ESDocMetaDataEntity> payload) throws IOException {
        return new ResponseEntity<List<ESDocMetaDataEntity>>(service.bulkInsert(payload), HttpStatus.OK);
    }

    @GetMapping(value = "/mappings", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Map<String, String>> getAllProperties(){
        return new ResponseEntity<Map<String, String>>(mappingConfig.getMappings(), HttpStatus.OK);
    }

    @GetMapping(value = "/helloworld", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> helloWorld(){
        return new ResponseEntity<String>("hello world", HttpStatus.OK);
    }
}
