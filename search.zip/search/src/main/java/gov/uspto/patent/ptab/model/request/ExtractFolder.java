package gov.uspto.patent.ptab.model.request;

import lombok.Getter;

@Getter
public class ExtractFolder {
    private String folderPath;
}
