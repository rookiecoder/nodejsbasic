package gov.uspto.patent.ptab.service.ner;

import edu.stanford.nlp.pipeline.CoreDocument;
import edu.stanford.nlp.pipeline.CoreEntityMention;
import edu.stanford.nlp.pipeline.StanfordCoreNLP;
import gov.uspto.patent.ptab.config.Config;
import gov.uspto.patent.ptab.model.ServiceResponseContent;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Slf4j
@Component
public class NERExtractor implements Extractor {

    @Autowired
    private StanfordCoreNLP stanfordCoreNLP;

    @Autowired
    private Config config;

    public Map<String ,String>  extractEntities(String input){
        CoreDocument coreDocument = new CoreDocument(input);
        stanfordCoreNLP.annotate(coreDocument);
        Map<String ,String> mapping = new HashMap<>();
        System.out.println("Running extract... thread id: " + Thread.currentThread().getId());

        for (CoreEntityMention em : coreDocument.entityMentions()) {
            if (!config.getEntities().contains(em.entityType()) || !config.getEntitiesFilter().contains(em.text()))
                continue;
            mapping.put(em.text(),em.entityType());
        }
        return mapping;
    }

    @Override
    public List<CoreEntityMention> extractToCoreEntity(String input) {
        CoreDocument coreDocument = null;
        long startTime = System.nanoTime();
        try {
            coreDocument = new CoreDocument(input);
            stanfordCoreNLP.annotate(coreDocument);
        } catch (Exception e) {
            log.error("Error extracting entities "+e.getMessage());
        }
        return coreDocument.entityMentions().stream().filter(e -> config.getEntitiesFilter().stream().anyMatch(e.text()::equalsIgnoreCase)).collect(Collectors.toList());
    }

    public CompletableFuture<Map<String, String>> submitExtractEntities(String input) {
        CompletableFuture<Map<String, String>> future = CompletableFuture.supplyAsync(() -> {
                System.out.println("Running extract... thread id: " + Thread.currentThread().getId());
            return extractEntities(input);
        });
        return future;
    }

    public List<CompletableFuture<Map<String, String>>> submitExtractEntities(List<String> inputs){
        List<CompletableFuture<Map<String, String>>> futures = new ArrayList<>();
        int size = inputs.size();

        IntStream.range(0, size).forEach(num -> {
            futures.add(CompletableFuture.supplyAsync(() -> extractEntities(inputs.get(num))));
        });

        CompletableFuture.allOf(futures.toArray(new CompletableFuture[0]))
                .thenRunAsync(() -> System.out.println("done"));
        return futures;
    }

    public List<CoreEntityMention> extractToCoreEntity(ServiceResponseContent responseContent) {
        CoreDocument coreDocument = null;
        try {
            coreDocument = new CoreDocument(responseContent.getResult().getText());
            stanfordCoreNLP.annotate(coreDocument);
        } catch (Exception e) {
            log.error("Error extracting entities "+e.getMessage());
        }
        return coreDocument.entityMentions().stream().filter(e -> config.getEntities().stream().anyMatch(e.text()::equalsIgnoreCase)).collect(Collectors.toList());
    }

   // @Async
    public Set<String> getEntitiesByType(List<CoreEntityMention> extractedEntities, String entityType) {
        Set<String> entitiesByType =   extractedEntities.stream().filter(e -> e.entityType().equals(entityType))
                .map(CoreEntityMention::text).collect(Collectors.toSet());
        return entitiesByType;
    }

   // @Async
    public Set<String> getTags(List<CoreEntityMention> extractedEntities) {
        return extractedEntities.stream().filter(e -> config.getEntities().stream().anyMatch(e.text()::equalsIgnoreCase))
                .map(CoreEntityMention::text).collect(Collectors.toSet());

    }

}
