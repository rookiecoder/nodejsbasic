package gov.uspto.patent.ptab.controller;

import gov.uspto.patent.ptab.model.request.ExtractFile;
import gov.uspto.patent.ptab.model.request.ExtractFolder;
import gov.uspto.patent.ptab.model.response.SuccessResponse;
import gov.uspto.patent.ptab.service.file.FilesStorageService;
import gov.uspto.patent.ptab.service.textextract.TextExtractService;
import gov.uspto.patent.ptab.utils.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

@RestController
@RequestMapping("/ptab/extract")
public class PtabExtractController {

    @Autowired
    FilesStorageService storageService;

    @Autowired
    TextExtractService textExtractService;

    @PostMapping("/uploadFile")
    public ResponseEntity<SuccessResponse> uploadExtractFile(@RequestParam("file") MultipartFile file) throws IOException {
        storageService.save(file);
        textExtractService.asyncProcess(file.getBytes());
        SuccessResponse response = new SuccessResponse("File is being processed", HttpStatus.ACCEPTED.value());
        return new ResponseEntity<>(response,HttpStatus.ACCEPTED);
    }

    @PostMapping("/file")
    public ResponseEntity<SuccessResponse> extractFile(@RequestBody ExtractFile file) throws IOException {
        textExtractService.asyncProcess(FileUtils.readFileContent(file.getFilepath()));
        SuccessResponse response = new SuccessResponse("File is being processed", HttpStatus.ACCEPTED.value());
        return new ResponseEntity<>(response,HttpStatus.ACCEPTED);
    }

    @PostMapping("/folder")
    public ResponseEntity<SuccessResponse> extractFilesInFolder(@RequestBody ExtractFolder folder) throws IOException {
        textExtractService.asyncProcess(folder.getFolderPath());
        SuccessResponse response = new SuccessResponse("Files in folder is being processed", HttpStatus.ACCEPTED.value());
        return new ResponseEntity<>(response,HttpStatus.ACCEPTED);
    }


}
