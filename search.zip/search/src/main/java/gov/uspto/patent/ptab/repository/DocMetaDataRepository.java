package gov.uspto.patent.ptab.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import gov.uspto.patent.ptab.model.DocMetaDataEntity;

@Repository
public interface DocMetaDataRepository extends JpaRepository<DocMetaDataEntity, Long> {

      @Query(value = "select * from VW_PROCEEDING_DOCUMENTS  vw inner join USPTO_CMS_DOCUMENT_LOAD  usp "
          + "on vw.content_management_id = usp.content_management_id where usp.SEARCH_INDEXING_STATUS='QUEUED' "
          + "and usp.alfresco_download_status= 'COMPLETED' and vw.proceeding_no LIKE 'CBM2015-001%'", nativeQuery = true)
      Page<DocMetaDataEntity> getCompletedDocumentInformation(Pageable pageable);

      @Query(value = "select count(DISTINCT vw.PROCEEDING_ARTIFACT_ID) FROM VW_PROCEEDING_DOCUMENTS  vw inner join USPTO_CMS_DOCUMENT_LOAD  usp "
          + "on vw.content_management_id = usp.content_management_id where usp.SEARCH_INDEXING_STATUS='QUEUED' "
          + "and usp.alfresco_download_status= 'COMPLETED'  and vw.proceeding_no LIKE 'CBM2015-001%'"
          , nativeQuery = true)
      int getQueuedDocumentCount();
}
