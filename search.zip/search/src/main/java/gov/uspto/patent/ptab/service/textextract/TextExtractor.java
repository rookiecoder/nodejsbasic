package gov.uspto.patent.ptab.service.textextract;

import org.apache.tika.exception.TikaException;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.parser.AutoDetectParser;
import org.apache.tika.parser.ParseContext;
import org.apache.tika.parser.Parser;
import org.apache.tika.parser.ocr.TesseractOCRConfig;
import org.apache.tika.parser.pdf.PDFParserConfig;
import org.apache.tika.sax.BodyContentHandler;
import org.springframework.stereotype.Component;
import org.xml.sax.SAXException;

import java.io.FileInputStream;
import java.io.IOException;

@Component
public class TextExtractor {

    public void parse(FileInputStream stream) throws IOException, TikaException, SAXException {

        final Parser parser = new AutoDetectParser();
        final BodyContentHandler handler = new BodyContentHandler(Integer.MAX_VALUE);

        final TesseractOCRConfig config = new TesseractOCRConfig();

        // commenting this out for now, need to set the path of tesseract installation for text extraction from OCR Image
        // pdf
        // config.setTesseractPath("tPath"); TODO

        final PDFParserConfig pdfConfig = new PDFParserConfig();
        pdfConfig.setExtractInlineImages(true);

        final ParseContext parseContext = new ParseContext();
        parseContext.set(TesseractOCRConfig.class, config);
        parseContext.set(PDFParserConfig.class, pdfConfig);
        // need to add this to make sure recursive parsing happens!
        parseContext.set(Parser.class, parser);
        final Metadata metadata = new Metadata();
        parser.parse(stream, handler, metadata, parseContext);

    }

}

