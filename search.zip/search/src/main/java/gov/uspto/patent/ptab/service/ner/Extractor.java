package gov.uspto.patent.ptab.service.ner;

import edu.stanford.nlp.pipeline.CoreEntityMention;

import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CompletableFuture;

public interface Extractor {
     Map<String ,String> extractEntities(String input);
     List<CoreEntityMention> extractToCoreEntity(String input);
     CompletableFuture<Map<String, String>> submitExtractEntities(String input);
     List<CompletableFuture<Map<String, String>>> submitExtractEntities(List<String> inputs);
     Set<String> getEntitiesByType(List<CoreEntityMention> extractedEntities, String entityType);
     Set<String> getTags(List<CoreEntityMention> extractedEntities);
}
