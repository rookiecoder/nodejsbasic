package gov.uspto.patent.ptab.service.textextract;

import static java.nio.file.StandardOpenOption.APPEND;
import static java.nio.file.StandardOpenOption.CREATE;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.Normalizer;
import java.time.Duration;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import org.apache.tika.io.TikaInputStream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import com.fasterxml.jackson.databind.ObjectMapper;
import gov.uspto.patent.ptab.model.CmsDocId;
import gov.uspto.patent.ptab.model.CmsDocumentLoadEntity;
import gov.uspto.patent.ptab.model.DocMetaDataEntity;
import gov.uspto.patent.ptab.model.ServiceResponseContent;
import gov.uspto.patent.ptab.model.TikaProcessingResult;
import gov.uspto.patent.ptab.repository.CmsDocumentLoadRepository;
import gov.uspto.patent.ptab.service.textextract.processor.CompositeTikaProcessor;
import edu.stanford.nlp.pipeline.CoreDocument;
import edu.stanford.nlp.pipeline.CoreEntityMention;
import edu.stanford.nlp.pipeline.StanfordCoreNLP;
import lombok.extern.slf4j.Slf4j;

@Slf4j @Component public class IngestService {

    private static final String DELIMITER = "/";

    private static final String REGEX_NON_ASCII = "[^\\p{ASCII}]";

    @Value("#{'${entities}'.split(',')}") private List<String> entities;

    @Value("${textextract.output.location}") String outputLocation;

    @Value("${textextract.input.location}") String fileLocation;

    @Value("${textextract.use.nlp}") boolean useNLP;

    @Autowired private StanfordCoreNLP stanfordCoreNLP;

    @Autowired @Qualifier("compositeTikaProcessor") 
    private CompositeTikaProcessor compositeTikaProcessor;

    //@Autowired 
    CmsDocumentLoadRepository cmsDocumentLoadRepository;

    public List<CoreEntityMention> extractEntities(String extractedText) {
        CoreDocument coreDocument = null;
        try {
            coreDocument = new CoreDocument(extractedText);
            stanfordCoreNLP.annotate(coreDocument);
        } catch (Exception e) {
            log.error("Error extracting entities " + e.getMessage());
        }
        return coreDocument.entityMentions();
    }

    public Set<String> getEntitiesByType(List<CoreEntityMention> extractedEntities, String entityType) {
        return extractedEntities.stream().filter(e -> e.entityType().equals(entityType)).map(CoreEntityMention::text)
            .collect(Collectors.toSet());
    }

    public Set<String> getTags(List<CoreEntityMention> extractedEntities) {
        return extractedEntities.stream().filter(e -> entities.stream().anyMatch(e.text()::equalsIgnoreCase))
            .map(CoreEntityMention::text).collect(Collectors.toSet());

    }

    @Async
    public void ingest(DocMetaDataEntity element) throws IOException {
        List<CmsDocId> contentManagementIds = new ArrayList<>();
        CmsDocId cmsDocId;
        ObjectMapper objectMapper = new ObjectMapper();
        Path outputPath = Paths.get(outputLocation + element.getProceedingNumber() + ".json");
        OutputStream outputStream = Files.newOutputStream(outputPath, CREATE, APPEND);
        String filePrefix = fileLocation + element.getProceedingNumber() + DELIMITER + element.getProceedingArtifactId();
        Path path = Paths.get(filePrefix + ".pdf");
        if (!Files.exists(path)) {
            path = Paths.get(filePrefix + "%2E");
        }
        log.info("****************reading data from file******* data" + filePrefix + ".json");

        if (Files.exists(path)) {
            long fileSize = Files.size(path) / 1024;
            log.info("file size is " + String.format("%,d kilo bytes", Files.size(path) / 1024));
            ServiceResponseContent responseContent = process(Files.readAllBytes(path));
            String extractedText = responseContent.getResult().getText().
                replaceAll("\n", "");;

            if(useNLP) {
                Instant start = Instant.now();
                List<CoreEntityMention> extractedEntities = extractEntities(extractedText);
                Instant finish = Instant.now();
                log.info("Time Taken for entity extraction " + Duration.between(start, finish).toMillis());
                element = populateDocMetaDataWithEntities(element, extractedEntities);
            }
            element.setExtractedContent(extractedText);
            String metadata =
                "{ \"index\" : { \"_index\" : \"ptab_documents\" , \"_id\" : \"" + element.getProceedingArtifactId() + "\" } }";
            synchronized (this) {
                outputStream.write(metadata.getBytes());
                outputStream.write("\r\n".getBytes());
                outputStream.write(objectMapper.writeValueAsBytes(element));
                outputStream.write("\r\n".getBytes());
            }
            /*cmsDocId = new CmsDocId(element.getContentManagementId(), element.getProceedingNumber());
            contentManagementIds.add(cmsDocId);*/
            log.info("****************writing data to file******* data" + outputLocation + element.getProceedingNumber() + element
                .getProceedingArtifactId() + ".json");

        } else {
            log.error("******Matching File not found **********" + Paths
                .get(fileLocation + element.getProceedingNumber() + "/" + element.getProceedingArtifactId()));
            Path outputPath1 = Paths.get(outputLocation + "nofile.json");
            OutputStream outputStream1 = Files.newOutputStream(outputPath1, CREATE, APPEND);
            outputStream1.write("filenotfound\r\n".getBytes());

        }

    }

    private DocMetaDataEntity populateDocMetaDataWithEntities(DocMetaDataEntity element,
        List<CoreEntityMention> extractedEntities) {
        if (extractedEntities != null) {
            element.setPerson(getEntitiesByType(extractedEntities, "PERSON"));
            element.setCity(getEntitiesByType(extractedEntities, "CITY"));
            element.setState(getEntitiesByType(extractedEntities, "STATE_OR_PROVINCE"));
            element.setCountry(getEntitiesByType(extractedEntities, "COUNTRY"));
            element.setPerson(getEntitiesByType(extractedEntities, "ORGANIZATION"));
            element.setTags(getTags(extractedEntities));
        }
        return element;
    }

    /**
     * Service to process files
     *
     * @param bytes
     */
    public ServiceResponseContent process(byte[] bytes) {
        // check whether we need to perform any processing
        if (bytes == null) {
            final String message = "Empty content";
            return createErrorResponse(message);
        }

        // process the content
        try {
            // we are buffering the stream using ByteArrayInputStream in order to enable
            // re-reading the binary document content
            ByteArrayInputStream byteBuffer = new ByteArrayInputStream(bytes);
            TikaProcessingResult result = processStream(byteBuffer);
            ServiceResponseContent response = new ServiceResponseContent();
            response.setResult(result);
            return response;
        } catch (Exception e) {
            final String message = "Error processing the query: " + e.getMessage();
            return createErrorResponse(message);
        }
    }

    private TikaProcessingResult processStream(ByteArrayInputStream stream) {
        return compositeTikaProcessor.processStream(TikaInputStream.get(stream));
    }

    private ServiceResponseContent createErrorResponse(String message) {
        ServiceResponseContent response = new ServiceResponseContent();
        TikaProcessingResult result = TikaProcessingResult.builder().success(false).error(message).build();
        response.setResult(result);
        return response;
    }

    public void updateSearchIndexingStatus(List<BigDecimal> artifactIds) {
        List<CmsDocumentLoadEntity> cmsDocumentLoadEntities = cmsDocumentLoadRepository.findAllById(artifactIds);

        cmsDocumentLoadEntities.forEach(e -> e.setSearchIndexingStatus("COMPLETED"));
        cmsDocumentLoadRepository.saveAll(cmsDocumentLoadEntities);
    }

}

