package gov.uspto.patent.ptab.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

@Component
@ConfigurationProperties(prefix = "prefix")
@EnableConfigurationProperties
public class Config {

    @Autowired
    private Environment env;

    public Set<String> getEntities() {
        String entities = env.getProperty("ner.entities");
        Set<String> hashSet = new HashSet<String>(Arrays.asList(entities.split(",")));
        return hashSet;
    }

    public Set<String> getEntitiesFilter() {
        String entities = env.getProperty("ner.entities.filter");
        Set<String> hashSet = new HashSet<String>(Arrays.asList(entities.split(",")));
        return hashSet;
    }

}
