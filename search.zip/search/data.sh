#!/bin/sh

a=0

for FILE in *;
do

  echo $a
  #curl -XPOST "localhost:9200/ptab_documents/_bulk?pretty" -H 'Content-Type: application/json'  --data-binary @/c/data/meta/test/data$a.json
  a=`expr $a + 1`
done

