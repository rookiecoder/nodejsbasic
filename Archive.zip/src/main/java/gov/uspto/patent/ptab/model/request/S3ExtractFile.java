package gov.uspto.patent.ptab.model.request;

import lombok.Getter;

@Getter
public class S3ExtractFile extends S3ExtractFolder {
    private String key;
}
