package gov.uspto.patent.ptab.service.es;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import gov.uspto.patent.ptab.config.MappingConfig;

import gov.uspto.patent.ptab.model.es.ESDocMetaDataEntity;
import gov.uspto.patent.ptab.model.es.ESDocMetaDataEntityWrite;
import gov.uspto.patent.ptab.utils.JSonUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.entity.ContentType;
import org.apache.http.nio.entity.NStringEntity;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.action.update.UpdateRequest;
import org.elasticsearch.client.*;
import org.elasticsearch.client.core.MainResponse;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.script.Script;
import org.elasticsearch.script.ScriptType;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;

import static java.util.Collections.singletonMap;

@Component
@Slf4j
public class ESDocumentService {

    @Value("${es.index}")
    private String esIndex;

    @Value("${es.index.nested}")
    private String esIndexNested;

    @Autowired
    private MappingConfig mappingConfig;

    @Autowired
    @Qualifier("elasticsearchClient")
    RestHighLevelClient restHighLevelClient;

    @Value("${es.host}")
    private String esHost ;

    @Value("${es.port}")
    private int esPort;

    @Value("${es.protocol}")
    private String esProtocol ;

    public List<ESDocMetaDataEntity> searchQuery(String searchQuery) throws IOException {
        JsonNode node = JSonUtil.removeAliases(searchQuery,mappingConfig.getMappings());
        String query = JSonUtil.getJsonPropertyValue(node);
        QueryBuilder builder = QueryBuilders.wrapperQuery(query);
        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        String [] sources = null;
        if(node.has("_source")){
            sources = JSonUtil.getSourceFields(node.get("_source"),mappingConfig.getMappings());
        }
        searchSourceBuilder.query(builder).fetchSource(sources,null);
        SearchRequest searchRequest = new SearchRequest(esIndex);
        searchRequest.source(searchSourceBuilder);
        SearchResponse searchResponse = restHighLevelClient.search(searchRequest, RequestOptions.DEFAULT);
        return JSonUtil.transformResponse(searchResponse);
    }

    public String searchNestedQuery(String searchQuery) throws IOException {
        JsonNode node = JSonUtil.removeAliases(searchQuery,mappingConfig.getMappings());
        String query = JSonUtil.getJsonPropertyValue(node);
        QueryBuilder builder = QueryBuilders.wrapperQuery(query);
        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        String [] sources = null;
        if(node.has("_source")){
            sources = JSonUtil.getSourceFields(node.get("_source"));
        }
        searchSourceBuilder.query(builder).fetchSource(sources,null);
        SearchRequest searchRequest = new SearchRequest(esIndexNested);
        searchRequest.source(searchSourceBuilder);
        SearchResponse searchResponse = restHighLevelClient.search(searchRequest, RequestOptions.DEFAULT);
        return JSonUtil.convert(searchResponse);
    }

    public ESDocMetaDataEntityWrite create(ESDocMetaDataEntityWrite payload) throws IOException {
        String json = JSonUtil.convert(payload);
        final IndexRequest indexRequest = new IndexRequest(esIndex)
                .source(json, XContentType.JSON);
        IndexResponse response = restHighLevelClient.index(indexRequest,RequestOptions.DEFAULT);
        return payload;
    }

    public ESDocMetaDataEntityWrite update(ESDocMetaDataEntityWrite payload, String proceedingNumber) throws IOException {
        String json = JSonUtil.convert(payload);
        JsonNode node = JSonUtil.convertStringToJsonNode(json);
        UpdateRequest updateRequest = new UpdateRequest(esIndexNested, proceedingNumber);
        Script script = new Script("");
        JsonNode parent   = JSonUtil.convertStringToJsonNode("\\\"{\\r\\n \\\"script\\\": {\\r\\n\\\"source\\\": \\\"ctx._source.documents.add(params.document)\\\",\\r\\n \\\"params\\\": {\\r\\n \\r\\n  }\\r\\n}\\\"");
        JsonNode children = parent.findParent("params");
        ((ObjectNode)children).put("document", node);
        updateRequest.script(script);
        restHighLevelClient.update(updateRequest, RequestOptions.DEFAULT);
        return payload;
    }

    public String update1() throws IOException {
        String id = searchById("");
        //Request request = new Request("POST", "http://localhost:9200/laptops/_update/"+id);
        String endPoint = String.format("%s://%s:%s/%s/_update/%s",esProtocol,esHost,esPort,"laptops",id);
        Request request = new Request("POST",endPoint );
        request.addParameter("refresh", "true");
        String json = JSonUtil.createScript();
        request.setEntity(new NStringEntity(json, ContentType.APPLICATION_JSON));
        restHighLevelClient.getLowLevelClient().performRequest(request);
        return "test";
    }

    public String update2() throws IOException {
        String id = searchById("");
        UpdateRequest updateRequest = new UpdateRequest("laptops", id);
        String json = JSonUtil.createScript();
        //Script script = new Script(json);
        HashMap<String, String> attributes = new HashMap<String, String>();
        attributes.put("attribute_name", "screen_size");
        attributes.put("attribute_value", "21 inch");

        Script script = new Script(ScriptType.INLINE, "painless", "ctx._source.attributes.add(params.attribute)",
                singletonMap("attribute", attributes));

        updateRequest.script(script);
        restHighLevelClient.update(updateRequest, RequestOptions.DEFAULT);
        return "test";
    }

    public String searchById(String proceedingNumber) throws IOException {
        SearchRequest searchRequest = new SearchRequest("laptops");
        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        searchSourceBuilder.query(QueryBuilders.matchQuery("name", "windows"));
        searchRequest.source(searchSourceBuilder);
        SearchResponse searchResponse = restHighLevelClient.search(searchRequest, RequestOptions.DEFAULT);
        SearchHits hits = searchResponse.getHits();
        if(hits!=null  && hits.getHits()!=null && hits.getHits().length > 0 ){
            SearchHit hit = hits.getHits()[0];
            return hit.getId();
        }
        return "-1";
    }

    public String searchByIdProceedingNumber(String proceedingNumber) throws IOException {
        SearchRequest searchRequest = new SearchRequest(esIndexNested);
        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        searchSourceBuilder.query(QueryBuilders.matchQuery("proceedingNumber", proceedingNumber));
        searchRequest.source(searchSourceBuilder);
        SearchResponse searchResponse = restHighLevelClient.search(searchRequest, RequestOptions.DEFAULT);
        SearchHits hits = searchResponse.getHits();
        if(hits!=null  && hits.getHits()!=null && hits.getHits().length > 0 ){
            SearchHit hit = hits.getHits()[0];
            return hit.getId();
        }
        return "-1";
    }

    public List<ESDocMetaDataEntity> bulkInsert(List<ESDocMetaDataEntity> payload) throws IOException {
        BulkRequest bulkRequest = new BulkRequest();

        payload.forEach(item -> {
            IndexRequest indexRequest = null;
            try {
                indexRequest = new IndexRequest(esIndex).
                        source(JSonUtil.convert(item), XContentType.JSON);
            } catch (JsonProcessingException e) {
                log.error(e.getMessage(), e);
            }

            bulkRequest.add(indexRequest);
        });

        try {
            restHighLevelClient.bulk(bulkRequest, RequestOptions.DEFAULT);
        } catch (IOException e) {
            log.error(e.getMessage(), e);
        }
        return payload;
    }

    @Scheduled(fixedRate = 1800000, initialDelay = 1000)
    public void keepAlive() throws IOException {
        MainResponse response = restHighLevelClient.info(RequestOptions.DEFAULT);
        System.out.println(response.getNodeName());
    }
}
