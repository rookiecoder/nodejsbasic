package gov.uspto.patent.ptab.model.es;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import gov.uspto.patent.ptab.utils.AliasName;
import lombok.Data;
import lombok.Getter;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Set;

import static gov.uspto.patent.ptab.utils.AliasNameConstants.*;


@JsonIgnoreProperties
@Data
public class ESDocMetaDataEntityWrite {

    private String extractedContent;

    private Set<String> organization;

    private Set<String> country;

    private Set<String> city;

    private Set<String> person;

    private String  contentManagementId;

    private String proceedingNumber;

    private BigDecimal documentNumber;

    private String documentTitle;

    private BigDecimal documentTypeId;

    private String documentTypeName;

    private String proceedingArtifactId;

    private String proceedingArtifactName;

    private String artifactTypeCd;

    private String proceedingTypeCd;

    private String fileName;

    private BigDecimal pageCount;

    private String confidentialityInd;

    private String availabilityCode;

    private Date filingTs;

    private String proxySubmitterRoleName;

    private Date loadedDate;

    private BigDecimal lastModUserId;

    private Set<String> state;

    private Set<String> tags;

}
