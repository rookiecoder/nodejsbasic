package gov.uspto.patent.ptab.model.es;

import lombok.Data;

@Data
public class Audit {
    private String lastModifiedTimestamp;
    private String lastModifiedUserIdentifier;
}
