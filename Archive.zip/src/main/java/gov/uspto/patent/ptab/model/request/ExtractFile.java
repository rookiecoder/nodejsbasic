package gov.uspto.patent.ptab.model.request;

import lombok.Getter;

@Getter
public class ExtractFile {
    private String filepath;
}
