package gov.uspto.patent.ptab.service.textextract;

import edu.stanford.nlp.pipeline.CoreEntityMention;
import gov.uspto.patent.ptab.model.*;
import gov.uspto.patent.ptab.model.es.ESDocMetaDataEntityWrite;
import gov.uspto.patent.ptab.repository.CmsDocumentLoadRepository;
import gov.uspto.patent.ptab.repository.DocMetaDataRepository;
import gov.uspto.patent.ptab.service.es.ESDocumentService;
import gov.uspto.patent.ptab.service.ner.Extractor;
import gov.uspto.patent.ptab.service.s3.S3Service;
import gov.uspto.patent.ptab.service.textextract.processor.CompositeTikaProcessor;
import gov.uspto.patent.ptab.utils.FileUtils;
import gov.uspto.patent.ptab.utils.JSonUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.tika.io.TikaInputStream;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.retry.annotation.Backoff;
import org.springframework.retry.annotation.Retryable;
import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.CompletableFuture;

@Slf4j
@Component
public class TextExtractService {

    private final Logger logger = LogManager.getLogger(TextExtractService.class);
    private static final String DELIMITER = "/";

    //@Autowired
    DocMetaDataRepository docMetaDataRepository;
    //@Autowired
    CmsDocumentLoadRepository cmsDocumentLoadRepository;
    @Autowired
    ESDocumentService service;

    @Autowired
    private Extractor stanfordNERExtractor;

    @Value("${textextract.input.location}")
    String fileLocation;

    @Value("${textextract.source.location}")
    String sourceLocation;

    @Value("${textextract.page.size}")
    int pageSize;

    @Value("${textextract.output.location}")
    String outputLocation;

    @Value("${aws.s3.es.bucket}")
    String s3Bucket;

    @Value("${es.path}")
    String esJsonPath;

    @Autowired
    private S3Service s3Service;

    @Autowired
    @Qualifier("compositeTikaProcessor")
    private CompositeTikaProcessor compositeTikaProcessor;

    public void  asyncProcess(String folderPath) throws IOException {
        File[] files = new File(folderPath).listFiles();
        for(File file: files){
            if(file.isFile()){
                log.info("processing file name : {} " ,file.getName());
                asyncProcess(FileUtils.readFileContent(file),file.getName(),"" );
            }
        }
    }

    @Retryable(maxAttempts=3,value=Exception.class,backoff=@Backoff(delay = 2000))
    public void  asyncProcess(byte[] bytes, final String fileName, final String proceedingNumber) {
        if (bytes == null) {
            final String message = "Empty content";
            logger.info(message);
        }
        CompletableFuture.runAsync(()-> {
            try {
                // we are buffering the stream using ByteArrayInputStream in order to enable
                // re-reading the binary document content
                ByteArrayInputStream byteBuffer = new ByteArrayInputStream(bytes);
                TikaProcessingResult result = processStream(byteBuffer);
                ServiceResponseContent response = new ServiceResponseContent();
                response.setResult(result);
                logger.info("extracting the contents of file  : {} " ,fileName);

                List<CoreEntityMention> extractedEntities = stanfordNERExtractor.extractToCoreEntity(result.getText());
                ESDocMetaDataEntityWrite element = setEntitiesType(extractedEntities,result.getText());
                logger.info("extracting the entities of file  : {} " ,fileName);
                s3Service.write(s3Bucket,fileName,JSonUtil.convert(element));
                JSonUtil.writeJsonToFile(JSonUtil.convert(element),esJsonPath);
                //System.out.println(JSonUtil.convert(element));
                service.update(element,proceedingNumber);
                logger.info("pushing the data to elsatic search " ,fileName);
            }
            catch (Exception e) {
                final String message = "Error processing the query: " + e.getMessage();
                logger.error(message);

            }

        });

    }

    private TikaProcessingResult processStream(ByteArrayInputStream stream) {
        return compositeTikaProcessor.processStream(TikaInputStream.get(stream));
    }

    private ESDocMetaDataEntityWrite setEntitiesType(List<CoreEntityMention> extractedEntities,String text ){
        ESDocMetaDataEntityWrite element = new ESDocMetaDataEntityWrite();
        element.setExtractedContent(text);
        if (extractedEntities != null) {
            element.setPerson(stanfordNERExtractor.getEntitiesByType(extractedEntities, "PERSON"));
            element.setCity(stanfordNERExtractor.getEntitiesByType(extractedEntities, "CITY"));
            element.setState(stanfordNERExtractor.getEntitiesByType(extractedEntities, "STATE_OR_PROVINCE"));
            element.setCountry(stanfordNERExtractor.getEntitiesByType(extractedEntities, "COUNTRY"));
            element.setOrganization(stanfordNERExtractor.getEntitiesByType(extractedEntities, "ORGANIZATION"));
            element.setTags(stanfordNERExtractor.getTags(extractedEntities));
        }
        return element;
    }

}