package gov.uspto.patent.ptab.service.s3;

import com.amazonaws.services.s3.AmazonS3Client;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;

@Component
public class S3Service {

    @Autowired
    AmazonS3Client amazonS3Client;

    public void write(String bucket,String key,String contents) throws IOException {
        amazonS3Client.putObject(bucket, key, contents);

    }

}
