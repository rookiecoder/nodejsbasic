package gov.uspto.patent.ptab.model;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Set;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Transient;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.*;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Data
@JsonIgnoreProperties
@Table(name = "VW_PROCEEDING_DOCUMENTS")
public class DocMetaDataEntity implements java.io.Serializable {

    private static final long serialVersionUID = -7571705803142462041L;

   /* @Id
    @Column(name = "CONTENT_MANAGEMENT_ID", unique = true, nullable = false)
    private String  contentManagementId;*/

    @Id
    @Column(name="PROCEEDING_ARTIFACT_ID")
    private BigDecimal proceedingArtifactId;

    @Column(name="PROCEEDING_NO")
    private String proceedingNumber;

   /* @Column(name="DOCUMENT_NO")
    private BigDecimal documentNumber;

    @Column(name="DOCUMENT_TITLE")
    private String documentTitle;*/

    @Column(name="FK_DOCUMENT_TYPE_ID")
    private BigDecimal documentTypeId;

    @Column(name="DOCUMENT_TYPE_NM")
    private String documentTypeName;

/*

    @Column(name="ARTIFACT_NM")
    private String proceedingArtifactName;

    @Column(name="ARTIFACT_TYPE_CD")
    private String artifactTypeCd;

    @Column(name="PROCEEDING_TYPE_CD")
    private String proceedingTypeCd;*/

    @Column(name="FILE_NM")
    private String fileName;

    /*@Column(name="PAGE_COUNT_QT")
    private BigDecimal pageCount;

    @Column(name="CONFIDENTIALITY_IN")
    private String confidentialityInd;

    @Column(name="FK_AVAILABILITY_CD")
    private String availabilityCode;*/

    @Column(name="FILING_TS")
    private Date filingTs;

/*    @Column(name ="FK_PROXY_SUBMITTER_ROLE_NM")
    private String proxySubmitterRoleName;*/

    @Column(name="LOADED_DT")
    private Date loadedDate;


    @Column(name ="LAST_MOD_USER_ID")
    private BigDecimal lastModUserId;

    @Column(name ="LAST_MOD_TS")
    private Date lastModTs;

    @Transient
    private Set<String> person;

    @Transient
    private Set<String> city;

    @Transient
    private Set<String> country;

    @Transient
    private Set<String> state;

    @Transient
    private Set<String> organization;

    @Transient
    private Set<String> tags;

    @Transient
    private String extractedContent;
}
