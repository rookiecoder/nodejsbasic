package gov.uspto.patent.ptab.model;

import lombok.*;

import javax.persistence.*;
import java.math.BigDecimal;

@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@ToString
@Table(name = "USPTO_CMS_DOCUMENT_LOAD")
//@IdClass(gov.uspto.patent.ptab.model.CmsDocId.class)
public class CmsDocumentLoadEntity implements java.io.Serializable {

    private static final long serialVersionUID = -7571705803142462041L;

    @Column(name = "CONTENT_MANAGEMENT_ID")
    private String  contentManagementId;

    @Column(name="PROCEEDING_NO")
    private String proceedingNumber;

    @Column(name="PROCEEDING_ID")
    private BigDecimal proceedingId;

    @Id
    @Column(name="PROCEEDING_ARTIFACT_ID")
    private BigDecimal proceedingArtifactId;

    @Column(name="USPTO_CMS_LOAD_STATUS")
    private String usptoCmsLoadStatus;

    @Column(name="ALFRESCO_DOWNLOAD_STATUS")
    private String alfrescoDownloadStatus;

    @Column(name="ALFRESCO_FILE_NAME")
    private String alfrescoFileName;

    @Column(name="SEARCH_INDEXING_STATUS")
    private String searchIndexingStatus;

    @Column(name="USPTO_CMS_OBJECTID")
    private String usptoCmsObjectId;


}
