package gov.uspto.patent.ptab.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.util.DefaultPrettyPrinter;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.ObjectWriter;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import gov.uspto.patent.ptab.model.es.ESDocMetaDataEntity;
import gov.uspto.patent.ptab.model.es.ESDocMetaDataEntityWrite;
import gov.uspto.patent.ptab.model.es.ESDocMetaDataParentEntity;
import org.codehaus.jettison.json.JSONArray;
import org.codehaus.jettison.json.JSONObject;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;

import java.io.File;
import java.io.IOException;
import java.util.*;

public class JSonUtil {
    static ObjectMapper objectMapper = new ObjectMapper();

    public static List<ESDocMetaDataEntity> transformResponse(String responseBody) throws JsonProcessingException {
        List<ESDocMetaDataEntity> documents = new ArrayList<>();
        JsonNode actualObj = objectMapper.readTree(responseBody);
        JsonNode hitParents = actualObj.get("hits");
        JsonNode hitsArrays = hitParents.get("hits");
        if (hitsArrays.isArray()) {
            for (JsonNode hitObject : hitsArrays) {
                ESDocMetaDataEntity dataDocument = objectMapper.convertValue(hitObject.get("_source"), ESDocMetaDataEntity.class);
                documents.add(dataDocument);
            }
        }
        return documents;
    }

    public static List<ESDocMetaDataEntity> transformResponse(SearchResponse searchResponse) throws JsonProcessingException {
        SearchHits hits = searchResponse.getHits();
        List<ESDocMetaDataEntity> documents = new ArrayList<>();
        Arrays.stream(hits.getHits()).forEach(hit -> {
            String source = hit.getSourceAsString();
            ESDocMetaDataEntity document = null;
            try {
                document = objectMapper.readValue(source, ESDocMetaDataEntity.class);
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
            documents.add(document);
        });
        return documents;
    }

    public static String transFromNestedResponse(SearchResponse response) throws JsonProcessingException {

        List<ESDocMetaDataParentEntity> parents = new ArrayList<>();
        for (SearchHit outerHit : response.getHits().getHits()) {
            ESDocMetaDataParentEntity parent = objectMapper.readValue(outerHit.getSourceAsString(), ESDocMetaDataParentEntity.class);
            if (outerHit.getInnerHits() != null && outerHit.getInnerHits().containsKey("documents")) {
               SearchHits maps = outerHit.getInnerHits().get("documents");
               List<ESDocMetaDataEntity> documents = new ArrayList<>();
               Arrays.stream(maps.getHits()).forEach(hit -> {
                    String source = hit.getSourceAsString();
                    ESDocMetaDataEntity document = null;
                    try {
                        document = objectMapper.readValue(source, ESDocMetaDataEntity.class);
                    } catch (JsonProcessingException e) {
                        e.printStackTrace();
                    }
                    documents.add(document);
               });
                parent.setDocuments(documents);
            }
            parents.add(parent);
        }

        return objectMapper.writeValueAsString(parents);
    }

    public static String convert(ESDocMetaDataEntityWrite data) throws JsonProcessingException {
        return objectMapper.writeValueAsString(data);
    }

    public static String convert(SearchResponse data) throws JsonProcessingException {
        return transFromNestedResponse(data);
    }

    public static String convert(ESDocMetaDataEntity data) throws JsonProcessingException {
        return objectMapper.writeValueAsString(data);
    }

    public static String getJsonPropertyValue(JsonNode node) throws JsonProcessingException {
        return node.get("query").toString();
    }

    public static JsonNode removeAliases(String json,Map<String, String> keys) throws JsonProcessingException {
        JsonNode parent = objectMapper.readTree(json);
        for (Map.Entry<String,String> key : keys.entrySet()) {
            List<JsonNode> children = parent.findParents(key.getKey());
            if(children == null || children.size()==0){
                continue   ;
            }

            for(JsonNode child : children){
                ((ObjectNode) child).put(key.getValue(), child.get(key.getKey()));
                ((ObjectNode) child).remove(key.getKey());
            }


        }
        return parent;
    }

    public static String[] getSourceFields(JsonNode array,Map<String, String> keys){
        if(!array.isArray())
            return null;
        List<String> sourceFields =new ArrayList<>();
        for(int index=0; index<array.size(); index++) {
            if(keys.containsKey(array.get(index).asText())) {
                sourceFields.add(keys.get(array.get(index).asText()));
            }
        }
        return sourceFields.toArray(String[]::new);
    }

    public static String[] getSourceFields(JsonNode array){
        if(!array.isArray())
            return null;
        List<String> sourceFields =new ArrayList<>();
        for(int index=0; index<array.size(); index++) {
                sourceFields.add(array.get(index).asText());
        }
        return sourceFields.toArray(String[]::new);
    }

    public static void writeJsonToFile(String jsonString, String path) throws IOException {
        ObjectWriter writer = objectMapper.writer(new DefaultPrettyPrinter());
        writer.writeValue(new File(path+ UUID.randomUUID().toString().replace("-", "")+".json"), jsonString);
    }

    public static String createScript() throws JsonProcessingException {

        JsonNode actualObj = convertStringToJsonNode("{\n" +
                "        \"attribute_name\": \"screen_size\",\n" +
                "        \"attribute_value\": \"99 inch\"\n" +
                "    }");

        String json = String.format("{\n" +
                        "  \"script\": {\n" +
                        "    \"source\": \"ctx._source.attributes.add(params.attribute)\",\n" +
                        "    \"lang\": \"painless\",\n" +
                        "    \"params\": {\n" +
                        "      \"attribute\": %s\n" +
                        "    }\n" +
                        "  }\n" +
                        "}",
                objectMapper.writeValueAsString(actualObj));

//        String json = String.format("{\n" +
//                        "    \"source\": \"ctx._source.attributes.add(params.attribute)\",\n" +
//                        "    \"lang\": \"painless\",\n" +
//                        "    \"params\": {\n" +
//                        "      \"attribute\": %s\n" +
//                        "    }\n" +
//                        "}\n",
//                objectMapper.writeValueAsString(actualObj));

        return json;
    }

    public static JsonNode createScript1() throws JsonProcessingException {

        JsonNode actualObj = convertStringToJsonNode("{\n" +
                "        \"attribute_name\": \"screen_size\",\n" +
                "        \"attribute_value\": \"15 inch\"\n" +
                "    }");

//        String json = String.format("{\n" +
//                        "  \"script\": {\n" +
//                        "    \"source\": \"ctx._source.attributes.add(params.attribute)\",\n" +
//                        "    \"lang\": \"painless\",\n" +
//                        "    \"params\": {\n" +
//                        "      \"attribute\": %s\n" +
//                        "    }\n" +
//                        "  }\n" +
//                        "}",
//                objectMapper.writeValueAsString(actualObj));

        String json = String.format("{\n" +
                        "    \"source\": \"ctx._source.attributes.add(params.attribute)\",\n" +
                        "    \"lang\": \"painless\",\n" +
                        "    \"params\": {\n" +
                        "      \"attribute\": %s\n" +
                        "    }\n" +
                        "}\n",
                objectMapper.writeValueAsString(actualObj));

        return actualObj;
    }


    public static String createScriptDocument() throws JsonProcessingException {

        JsonNode actualObj = convertStringToJsonNode("{\n" +
                "        \"attribute_name\": \"screen_size\",\n" +
                "        \"attribute_value\": \"15 inch\"\n" +
                "    }");

        String json = String.format("{\n" +
                        "  \"script\": {\n" +
                        "    \"source\": \"ctx._source.documents.add(params.document)\",\n" +
                        "    \"lang\": \"painless\",\n" +
                        "    \"params\": {\n" +
                        "      \"document\": %s\n" +
                        "    }\n" +
                        "  }\n" +
                        "}",
                objectMapper.writeValueAsString(actualObj));

        return json;
    }

    public static JsonNode convertStringToJsonNode(String data) throws JsonProcessingException {
        JsonNode actualObj = objectMapper.readTree(data);
        return actualObj;
    }
}
