package gov.uspto.patent.ptab.config;

import gov.uspto.patent.ptab.model.es.ESDocMetaDataEntity;
import gov.uspto.patent.ptab.utils.AliasName;
import org.springframework.stereotype.Component;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

@Component
public class MappingConfig {

    public Map<String, String> getMappings() {
        Map<String, String> mappings = new HashMap<>();
        Field[] classMemberFields = ESDocMetaDataEntity.class.getDeclaredFields();
        for(Field field : classMemberFields){
            AliasName property = field.getAnnotation(AliasName.class);
            if(property!=null){
                mappings.put(property.name(),field.getName());
            }

        }
        return mappings;
    }

    public Map<String, String> getPropertyToAlias() {
        Map<String, String> mappings = new HashMap<>();
        Field[] classMemberFields = ESDocMetaDataEntity.class.getDeclaredFields();
        for(Field field : classMemberFields){
            AliasName property = field.getAnnotation(AliasName.class);
            if(property!=null){
                mappings.put(field.getName(),property.name());
            }

        }

        return mappings;
    }


}
