package gov.uspto.patent.ptab.model.es;

public class MileStone {

    private ProceedingMileStoneResponse proceedingMileStoneResponse;
}
