package gov.uspto.patent.ptab.service.textextract.processor;

import gov.uspto.patent.ptab.config.textextract.CompositeTikaProcessorConfig;
import gov.uspto.patent.ptab.model.TikaProcessingResult;
import gov.uspto.patent.ptab.service.textextract.TextExtractService;
import gov.uspto.patent.ptab.utils.TikaUtils;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.apache.tika.config.TikaConfig;
import org.apache.tika.io.TikaInputStream;
import org.apache.tika.metadata.Metadata;
import org.apache.tika.mime.MediaType;
import org.apache.tika.parser.AutoDetectParser;
import org.apache.tika.parser.ParseContext;
import org.apache.tika.parser.Parser;
import org.apache.tika.parser.html.HtmlParser;
import org.apache.tika.parser.pdf.PDFParser;
import org.apache.tika.parser.pdf.PDFParserConfig;
import org.apache.tika.sax.BodyContentHandler;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.time.OffsetDateTime;
import java.util.Map;

/**
 * A default, composite Tika processor.
 *
 * In contrast to "legacy" processor it uses the default approach implemented in Tika, i.e. when
 * parsing PDF documents, it runs the processing independently per each PDF page,
 * and hence running Tesseract Page-Count times.
 */
@Component("compositeTikaProcessor")
public class CompositeTikaProcessor {

    @Autowired
    private CompositeTikaProcessorConfig compositeTikaProcessorConfig;


    /**
     In order to properly handle PDF documents and OCR we need three separate parsers:
     - a generic parser (for any, non-PDF document type),
     - one that will extract text only from PDFs,
     - one that will apply OCR on PDFs (when stored only images).

     In the default configuration of PDFParser the OCR is disabled when extracting text from PDFs. However, OCR is
     enabled when extracting text from documents of image type. When using default parser with OCR enabled (strategy:
     extract both text and OCR), it will actually always apply OCR on the PDFs even when there is text-only provided.

     We would also like to know when OCR was applied as it will affect the accuracy of the extracted text that will be
     passed to the downstream analysis applications.
     */

    // common tika and parsers configuration
    private TikaConfig tikaConfig;

    // the default, generic parser for handling all document types (except PDF)
    private AutoDetectParser defaultParser;
    private ParseContext defaultParseContext;

    // the default parser for PDFs (no OCR)
    private PDFParser pdfTextParser;
    private ParseContext pdfTextParseContext;

    // the parser to extract text from PDFs using OCR
    private PDFParser pdfOcrParser;
    private ParseContext pdfOcrParseContext;

    // the parser to extract text from PDFs using OCR only for single-pages
    // (used to strip-off clutter from LibreOffice-generated PDFs just with images)
    //private LegacyPdfProcessorParser pdfSinglePageOcrParser; TODO
    private ParseContext pdfSinglePageOcrParseContext;

    private final Logger logger = LogManager.getLogger(TextExtractService.class);

    @PostConstruct
    public void init() throws Exception {

        tikaConfig = new TikaConfig();

        initializeDefaultParser();

        initializePdfTextOnlyParser();

        //initializePdfOcrParser();

     }

    public void reset() throws Exception {
        // actually, we only need to re-initialize all the resources apart from the configuration
        init();
    }

    public TikaProcessingResult processStream(TikaInputStream stream) {

        TikaProcessingResult result;
        try {
            final int MIN_TEXT_BUFFER_SIZE = 1;
            ByteArrayOutputStream outStream = new ByteArrayOutputStream(MIN_TEXT_BUFFER_SIZE);
            BodyContentHandler handler = new BodyContentHandler(outStream);
            Metadata metadata = new Metadata();

            // mark the stream for multi-pass processing
            if (stream.markSupported()) {
                stream.mark(Integer.MAX_VALUE);
            }

            // try to detect whether the document is PDF
            if (isDocumentOfPdfType(stream)) {
                // firstly try the default parser
                pdfTextParser.parse(stream, handler, metadata, pdfTextParseContext);

                // check if there have been enough characters read / extracted and that we read enough bytes from the stream
                // (images embedded in the documents will occupy quite more space than just raw text)
                if (outStream.size() >= compositeTikaProcessorConfig.getPdfMinDocTextLength() && stream.getPosition() > compositeTikaProcessorConfig.getPdfMinDocByteSize()) {
                    // since we are performing a second pass over the document, we need to reset cursor position
                   /* // in both input and output streams
                    stream.reset();
                    outStream.reset();

                    final boolean useOcrLegacyParser = compositeTikaProcessorConfig.isUseLegacyOcrParserForSinglePageDocuments()
                            && TikaUtils.getPageCount(metadata) == 1;

                    // TODO: Q: shall we use a clean metadata or re-use some of the previously parsed fields???
                    handler = new BodyContentHandler(outStream);
                    metadata = new Metadata();

                    if (useOcrLegacyParser) {
                        //TODO
                        *//*pdfSinglePageOcrParser.parse(stream, handler, metadata, pdfSinglePageOcrParseContext);
                        // since we use the parser manually, update the metadata with the name of the parser class used
                        metadata.add("X-Parsed-By", LegacyPdfProcessorParser.class.getName());*//*
                    }
                    else {
                        pdfOcrParser.parse(stream, handler, metadata, pdfOcrParseContext);
                        // since we use the parser manually, update the metadata with the name of the parser class used
                        metadata.add("X-Parsed-By", PDFParser.class.getName());
                    }*/
                }
                else {
                    // since we use the parser manually, update the metadata with the name of the parser class used
                    metadata.add("X-Parsed-By", PDFParser.class.getName());
                }
            }
            else if (isDocumentOfHTMLType(stream)) {
                HtmlParser htmlParser = new HtmlParser();
                defaultParseContext.set(HtmlParser.class, htmlParser);
                htmlParser.parse(stream, handler, metadata, defaultParseContext);
                metadata.add("X-Parsed-By", HtmlParser.class.getName());
            }
            else {
                // otherwise, run default documents parser
                defaultParser.parse(stream, handler, metadata, defaultParseContext);
                metadata.add("X-Parsed-By", AutoDetectParser.class.getName());
            }

            // parse the metadata and store the result
            Map<String, Object> resultMeta = TikaUtils.extractMetadata(metadata);

            result = TikaProcessingResult.builder()
                    .text(outStream.toString())
                    .metadata(resultMeta)
                    .success(true)
                    .timestamp(OffsetDateTime.now().toString())
                    .build();
        }
        catch (Exception e) {
            logger.error(e.getMessage());

            result = TikaProcessingResult.builder()
                    .error("Exception caught while processing the document: " + e.getMessage())
                    .success(false)
                    .build();
        }

        return result;
    }



    private boolean isDocumentOfPdfType(InputStream stream) throws Exception {
        Metadata metadata = new Metadata();
        MediaType mediaType = defaultParser.getDetector().detect(stream, metadata);
        return mediaType.equals(MediaType.application("pdf"));
    }

    private boolean isDocumentOfImageType(InputStream stream) throws Exception {
        Metadata metadata = new Metadata();
        MediaType mediaType = defaultParser.getDetector().detect(stream, metadata);
        return mediaType.getType().contains("image");
    }

    private boolean isDocumentOfHTMLType(InputStream stream) throws Exception {
        Metadata metadata = new Metadata();
        MediaType mediaType = defaultParser.getDetector().detect(stream, metadata);
        return mediaType.getSubtype().contains("html");
    }



    private void initializeDefaultParser() {
        defaultParser = new AutoDetectParser(tikaConfig);

        defaultParseContext = new ParseContext();
        defaultParseContext.set(TikaConfig.class, tikaConfig);
        //defaultParseContext.set(TesseractOCRConfig.class, tessConfig);
        defaultParseContext.set(AutoDetectParser.class, defaultParser);
        defaultParseContext.set(Parser.class, defaultParser); //need to add this to make sure recursive parsing happens!
    }

    private void initializePdfTextOnlyParser() {
        PDFParserConfig pdfTextOnlyConfig = new PDFParserConfig();
        pdfTextOnlyConfig.setExtractInlineImages(false);
        pdfTextOnlyConfig.setExtractUniqueInlineImagesOnly(false); // do not extract multiple inline images
        pdfTextOnlyConfig.setOcrStrategy(PDFParserConfig.OCR_STRATEGY.NO_OCR);

        pdfTextParser = new PDFParser();
        pdfTextParseContext = new ParseContext();
        pdfTextParseContext.set(TikaConfig.class, tikaConfig);
        pdfTextParseContext.set(PDFParserConfig.class, pdfTextOnlyConfig);
        pdfTextParseContext.set(Parser.class, defaultParser); //need to add this to make sure recursive parsing happens!
    }



}
