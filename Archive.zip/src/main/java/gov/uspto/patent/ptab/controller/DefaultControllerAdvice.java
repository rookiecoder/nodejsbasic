package gov.uspto.patent.ptab.controller;

import gov.uspto.patent.ptab.model.response.ErrorResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.ResponseStatus;

import static org.springframework.http.HttpStatus.BAD_REQUEST;

@Slf4j
@ControllerAdvice
public class DefaultControllerAdvice {

    /**
     * Simple handler for RuntimeException
     *
     * @param exception - ConstraintViolationException
     * @return - Error messages along with field names and status code
     */
    @ExceptionHandler(RuntimeException.class)
    @ResponseStatus(BAD_REQUEST)
    @ResponseBody
    public ErrorResponse genericRuntimeException(final RuntimeException exception) {
        final String message = exception.getMessage();
        System.out.println(message);
        return new ErrorResponse(message);
    }

}
