package gov.uspto.patent.ptab.model.es;

public class DecisionOutcomeDetails {
}
