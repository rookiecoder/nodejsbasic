package gov.uspto.patent.ptab.model;

import java.io.Serializable;

public class CmsDocId implements Serializable {

    private String  contentManagementId;

    private String proceedingNumber;


    public CmsDocId(String contentManagementId, String proceedingNumber) {
        this.contentManagementId = contentManagementId;
        this.proceedingNumber = proceedingNumber;
    }

    public CmsDocId() {
    }
}
