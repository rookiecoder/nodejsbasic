package gov.uspto.patent.ptab.model.es;

public class MileStoneData {

    private String mileStoneDate;
    private String mileStoneTypeName;
    private String mileStoneDescription;
}
