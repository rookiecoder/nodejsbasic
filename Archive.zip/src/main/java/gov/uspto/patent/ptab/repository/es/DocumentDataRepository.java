package gov.uspto.patent.ptab.repository.es;

import org.springframework.stereotype.Repository;

@Repository
public interface DocumentDataRepository  {

}
