package gov.uspto.patent.ptab.model.es;

import lombok.Data;

import java.util.List;

@Data
public class AllPartiesInfo {
    private List<String> counselList;
    private String realParty;
    private List<String> additionalPartyList;
    private PatentOwner patentOwner;
}
