package gov.uspto.patent.ptab.model.es;

import java.util.List;

public class ProceedingMileStoneResponse {
    private List<MileStoneData> mileStoneData;
    private LatestOutcomeDetails latestOutcomeDetails;
}
