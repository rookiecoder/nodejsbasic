package gov.uspto.patent.ptab.repository;

import java.math.BigDecimal;

import gov.uspto.patent.ptab.model.CmsDocId;
import gov.uspto.patent.ptab.model.CmsDocumentLoadEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CmsDocumentLoadRepository extends JpaRepository<CmsDocumentLoadEntity, BigDecimal> {


}
