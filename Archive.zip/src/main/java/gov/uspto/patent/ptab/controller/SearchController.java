package gov.uspto.patent.ptab.controller;

import gov.uspto.patent.ptab.config.MappingConfig;
import gov.uspto.patent.ptab.model.es.ESDocMetaDataEntity;
import gov.uspto.patent.ptab.model.es.ESDocMetaDataEntityWrite;
import gov.uspto.patent.ptab.service.es.ESDocumentService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.io.IOException;
import java.util.List;
import java.util.Map;

@RestController
@Slf4j
@RequestMapping("/ptab/search")
public class SearchController {

    @Autowired
    ESDocumentService service;

    @Autowired
    private MappingConfig mappingConfig;

    @PostMapping(value = "/search", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<ESDocMetaDataEntity>> documentSearch(@RequestBody String payload) throws IOException {
        return new ResponseEntity<List<ESDocMetaDataEntity>>(service.searchQuery(payload), HttpStatus.OK);
    }

    @PostMapping(value = "/nestedSearch", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> documentSearchNested(@RequestBody String payload) throws IOException {
        return new ResponseEntity<String>(service.searchNestedQuery(payload), HttpStatus.OK);
    }

    @PostMapping(value = "/create", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<ESDocMetaDataEntityWrite> create(@RequestBody ESDocMetaDataEntityWrite payload) throws IOException {
        return new ResponseEntity<ESDocMetaDataEntityWrite>(service.create(payload), HttpStatus.OK);
    }

    @PostMapping(value = "/bulk", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<ESDocMetaDataEntity>> create(@RequestBody List<ESDocMetaDataEntity> payload) throws IOException {
        return new ResponseEntity<List<ESDocMetaDataEntity>>(service.bulkInsert(payload), HttpStatus.OK);
    }

    @PostMapping(value = "/update", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<String> update() throws IOException {
        return new ResponseEntity<String>(service.update1(), HttpStatus.OK);
    }

    @GetMapping(value = "/mappings", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Map<String, String>> getAllProperties(){
        return new ResponseEntity<Map<String, String>>(mappingConfig.getMappings(), HttpStatus.OK);
    }
}
