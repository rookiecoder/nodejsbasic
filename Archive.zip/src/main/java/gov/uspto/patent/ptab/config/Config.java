package gov.uspto.patent.ptab.config;

import com.amazonaws.auth.AWSStaticCredentialsProvider;
import com.amazonaws.auth.DefaultAWSCredentialsProviderChain;
import com.amazonaws.services.s3.AmazonS3Client;
import com.amazonaws.services.s3.AmazonS3ClientBuilder;
import gov.uspto.patent.ptab.service.file.FilesStorageService;
import gov.uspto.patent.ptab.service.file.FilesStorageServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.core.env.Environment;
import org.springframework.stereotype.Component;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;

@Component
@ConfigurationProperties(prefix = "prefix")
@EnableConfigurationProperties
public class Config {

    @Autowired
    private Environment env;

    @Value("${file.upload-dir}")
    private String uploadDirectory;

    public Set<String> getEntities() {
        String entities = env.getProperty("ner.entities");
        Set<String> hashSet = new HashSet<String>(Arrays.asList(entities.split(",")));
        return hashSet;
    }

    public Set<String> getEntitiesFilter(String entityType) {
        String entities = env.getProperty("ner.entities.filter."+entityType);
        Set<String> hashSet = new HashSet<String>(Arrays.asList(entities.split(",")));
        return hashSet;
    }

    @Bean("storageService")
    public FilesStorageService filesStorageService() {
        return new FilesStorageServiceImpl(uploadDirectory);
    }


    @Bean
    public static AmazonS3Client amazonS3Client(AWSStaticCredentialsProvider authProvider) {
        return (AmazonS3Client) AmazonS3ClientBuilder.standard()
                .withCredentials(authProvider)
                .withRegion("us-east-1")
                .build();
    }


}
