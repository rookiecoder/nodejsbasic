package gov.uspto.patent.ptab.model.es;

public class LatestOutcomeDetails {
    private String outcomeType;
    private String descriptionText;
}
