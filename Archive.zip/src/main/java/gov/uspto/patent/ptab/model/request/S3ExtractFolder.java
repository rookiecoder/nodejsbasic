package gov.uspto.patent.ptab.model.request;

import lombok.Getter;

@Getter
public class S3ExtractFolder {
    private String bucket;
}
