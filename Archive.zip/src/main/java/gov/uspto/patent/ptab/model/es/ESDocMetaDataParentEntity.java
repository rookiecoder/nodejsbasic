package gov.uspto.patent.ptab.model.es;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;
import gov.uspto.patent.ptab.utils.AliasName;
import lombok.Data;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Set;

import static gov.uspto.patent.ptab.utils.AliasNameConstants.*;


@JsonIgnoreProperties(ignoreUnknown = true)
@Data
public class ESDocMetaDataParentEntity {
    private String initiatedUser;
    private String institutionDecisionDate;
    private List<String> judges;
    private String nofda;
    private String petiRealParty;
    private String poApplicationId;
    private String poPatentNumber;
    private String poTechCenterId;
    private String proceedingNumber;
    private String statusDisplay;
    private String submittedDate;
    private String terminationDate;
    private String terminationType;
    private String poArtUnitcd;
    private AllPartiesInfo allPartiesInfo;
    private List<ESDocMetaDataEntity> documents;
}
