package com.demo.aws.elasticsearch.data.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import lombok.Data;

@Data
@JsonIgnoreProperties
public class DataDocument {
    private String extractedContent;
    private String[] organisation;
    private String[] country;
    private String[] city;
    private String[] person;
    private String[] state;
    private String[] tags;
}
