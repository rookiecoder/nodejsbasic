package com.demo.aws.elasticsearch.data.model;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonProperty;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Set;

import static com.demo.aws.elasticsearch.data.model.AliasNameConstants.*;

@JsonIgnoreProperties
public class DataDocument {

    @AliasName(name = EXTRACTED_CONTENT)
    private String extractedContent;

    @AliasName(name = ORGANISATION)
    private Set<String> organisation;

    @AliasName(name = COUNTRY)
    private Set<String> country;

    @AliasName(name = CITY)
    private Set<String> city;

    @AliasName(name= PERSON)
    private Set<String> person;

    @AliasName(name = CONTENT_MANAGEMENT_ID)
    private String  contentManagementId;

    @AliasName(name = PROCEEDING_NUMBER)
    private String proceedingNumber;

    @AliasName(name = DOCUMENT_NUMBER)
    private BigDecimal documentNumber;

    @AliasName(name = DOCUMENT_TITLE)
    private String documentTitle;

    @AliasName(name = DOCUMENT_TYPE_ID)
    private BigDecimal documentTypeId;

    @AliasName(name = DOCUMENT_TYPE_NAME)
    private String documentTypeName;

    @AliasName(name = PROCEEDING_ARTIFACT_ID)
    private String proceedingArtifactId;

    @AliasName(name = PROCEEDING_ARTIFACT_NAME)
    private String proceedingArtifactName;

    @AliasName(name = ARTIFACT_TYPE_CD)
    private String artifactTypeCd;

    @AliasName(name = PROCEEDING_TYPE_CD)
    private String proceedingTypeCd;

    @AliasName(name = FILE_NAME)
    private String fileName;

    @AliasName(name = PAGE_COUNT)
    private BigDecimal pageCount;

    @AliasName(name = CONFIDENTIALITY_IND)
    private String confidentialityInd;

    @AliasName(name = AVAILABILITY_CODE)
    private String availabilityCode;

    @AliasName(name = FILING_TS)
    private Date filingTs;

    @AliasName(name = PROXY_SUBMITTER_ROLE_NAME)
    private String proxySubmitterRoleName;

    @AliasName(name = LOADED_DATE)
    private Date loadedDate;

    @AliasName(name = LAST_MOD_USERID)
    private BigDecimal lastModUserId;

    @AliasName(name = STATE)
    private Set<String> state;

    @AliasName(name = TAGS)
    private Set<String> tags;

    @JsonProperty(value = CONTENT_MANAGEMENT_ID, access = JsonProperty.Access.READ_ONLY)
    public String getContentManagementId() {
        return contentManagementId;
    }

    @JsonProperty(value = "contentManagementId", access = JsonProperty.Access.WRITE_ONLY)
    public void setContentManagementId(String contentManagementId) {
        this.contentManagementId = contentManagementId;
    }

    @JsonProperty(value = PROCEEDING_NUMBER, access = JsonProperty.Access.READ_ONLY)
    public String getProceedingNumber() {
        return proceedingNumber;
    }

    @JsonProperty(value = "proceedingNumber", access = JsonProperty.Access.WRITE_ONLY)
    public void setProceedingNumber(String proceedingNumber) {
        this.proceedingNumber = proceedingNumber;
    }

    @JsonProperty(value = DOCUMENT_NUMBER, access = JsonProperty.Access.READ_ONLY)
    public BigDecimal getDocumentNumber() {
        return documentNumber;
    }

    @JsonProperty(value = "documentNumber", access = JsonProperty.Access.WRITE_ONLY)
    public void setDocumentNumber(BigDecimal documentNumber) {
        this.documentNumber = documentNumber;
    }

    @JsonProperty(value = DOCUMENT_TITLE, access = JsonProperty.Access.READ_ONLY)
    public String getDocumentTitle() {
        return documentTitle;
    }

    @JsonProperty(value = "documentTitle", access = JsonProperty.Access.WRITE_ONLY)
    public void setDocumentTitle(String documentTitle) {
        this.documentTitle = documentTitle;
    }

    @JsonProperty(value = DOCUMENT_TYPE_ID, access = JsonProperty.Access.READ_ONLY)
    public BigDecimal getDocumentTypeId() {
        return documentTypeId;
    }

    @JsonProperty(value = "documentTypeId", access = JsonProperty.Access.WRITE_ONLY)
    public void setDocumentTypeId(BigDecimal documentTypeId) {
        this.documentTypeId = documentTypeId;
    }

    @JsonProperty(value = DOCUMENT_TYPE_NAME, access = JsonProperty.Access.READ_ONLY)
    public String getDocumentTypeName() {
        return documentTypeName;
    }

    @JsonProperty(value = "documentTypeName", access = JsonProperty.Access.WRITE_ONLY)
    public void setDocumentTypeName(String documentTypeName) {
        this.documentTypeName = documentTypeName;
    }

    @JsonProperty(value = PROCEEDING_ARTIFACT_ID, access = JsonProperty.Access.READ_ONLY)
    public String getProceedingArtifactId() {
        return proceedingArtifactId;
    }

    @JsonProperty(value = "proceedingArtifactId", access = JsonProperty.Access.WRITE_ONLY)
    public void setProceedingArtifactId(String proceedingArtifactId) {
        this.proceedingArtifactId = proceedingArtifactId;
    }

    @JsonProperty(value = PROCEEDING_ARTIFACT_NAME, access = JsonProperty.Access.READ_ONLY)
    public String getProceedingArtifactName() {
        return proceedingArtifactName;
    }

    @JsonProperty(value = "proceedingArtifactName", access = JsonProperty.Access.WRITE_ONLY)
    public void setProceedingArtifactName(String proceedingArtifactName) {
        this.proceedingArtifactName = proceedingArtifactName;
    }

    @JsonProperty(value = ARTIFACT_TYPE_CD, access = JsonProperty.Access.READ_ONLY)
    public String getArtifactTypeCd() {
        return artifactTypeCd;
    }

    @JsonProperty(value = "artifactTypeCd", access = JsonProperty.Access.WRITE_ONLY)
    public void setArtifactTypeCd(String artifactTypeCd) {
        this.artifactTypeCd = artifactTypeCd;
    }

    @JsonProperty(value = PROCEEDING_TYPE_CD, access = JsonProperty.Access.READ_ONLY)
    public String getProceedingTypeCd() {
        return proceedingTypeCd;
    }

    @JsonProperty(value = "proceedingTypeCd", access = JsonProperty.Access.WRITE_ONLY)
    public void setProceedingTypeCd(String proceedingTypeCd) {
        this.proceedingTypeCd = proceedingTypeCd;
    }

    @JsonProperty(value = FILE_NAME, access = JsonProperty.Access.READ_ONLY)
    public String getFileName() {
        return fileName;
    }

    @JsonProperty(value = "fileName", access = JsonProperty.Access.WRITE_ONLY)
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    @JsonProperty(value = PAGE_COUNT, access = JsonProperty.Access.READ_ONLY)
    public BigDecimal getPageCount() {
        return pageCount;
    }

    @JsonProperty(value = "pageCount", access = JsonProperty.Access.WRITE_ONLY)
    public void setPageCount(BigDecimal pageCount) {
        this.pageCount = pageCount;
    }

    @JsonProperty(value = CONFIDENTIALITY_IND, access = JsonProperty.Access.READ_ONLY)
    public String getConfidentialityInd() {
        return confidentialityInd;
    }

    @JsonProperty(value = "confidentialityInd", access = JsonProperty.Access.WRITE_ONLY)
    public void setConfidentialityInd(String confidentialityInd) {
        this.confidentialityInd = confidentialityInd;
    }

    @JsonProperty(value = AVAILABILITY_CODE, access = JsonProperty.Access.READ_ONLY)
    public String getAvailabilityCode() {
        return availabilityCode;
    }

    @JsonProperty(value = "availabilityCode", access = JsonProperty.Access.WRITE_ONLY)
    public void setAvailabilityCode(String availabilityCode) {
        this.availabilityCode = availabilityCode;
    }

    @JsonProperty(value = FILING_TS, access = JsonProperty.Access.READ_ONLY)
    public Date getFilingTs() {
        return filingTs;
    }

    @JsonProperty(value = "filingTs", access = JsonProperty.Access.WRITE_ONLY)
    public void setFilingTs(Date filingTs) {
        this.filingTs = filingTs;
    }

    @JsonProperty(value = PROXY_SUBMITTER_ROLE_NAME, access = JsonProperty.Access.READ_ONLY)
    public String getProxySubmitterRoleName() {
        return proxySubmitterRoleName;
    }

    @JsonProperty(value = "proxySubmitterRoleName", access = JsonProperty.Access.WRITE_ONLY)
    public void setProxySubmitterRoleName(String proxySubmitterRoleName) {
        this.proxySubmitterRoleName = proxySubmitterRoleName;
    }

    @JsonProperty(value = LOADED_DATE, access = JsonProperty.Access.READ_ONLY)
    public Date getLoadedDate() {
        return loadedDate;
    }

    @JsonProperty(value = "loadedDate", access = JsonProperty.Access.WRITE_ONLY)
    public void setLoadedDate(Date loadedDate) {
        this.loadedDate = loadedDate;
    }

    @JsonProperty(value = LAST_MOD_USERID, access = JsonProperty.Access.READ_ONLY)
    public BigDecimal getLastModUserId() {
        return lastModUserId;
    }

    @JsonProperty(value = "lastModUserId", access = JsonProperty.Access.WRITE_ONLY)
    public void setLastModUserId(BigDecimal lastModUserId) {
        this.lastModUserId = lastModUserId;
    }

    @JsonProperty(value = LAST_MODIFIED_DATE, access = JsonProperty.Access.READ_ONLY)
    public Date getLastModTs() {
        return lastModTs;
    }

    @JsonProperty(value = "lastModTs", access = JsonProperty.Access.WRITE_ONLY)
    public void setLastModTs(Date lastModTs) {
        this.lastModTs = lastModTs;
    }

    @AliasName(name = LAST_MODIFIED_DATE)
    private Date lastModTs;

    public DataDocument() {
    }

    @JsonProperty(value = EXTRACTED_CONTENT, access = JsonProperty.Access.READ_ONLY)
    public String getExtractedContent() {
        return extractedContent;
    }

    @JsonProperty(value = "extractedContent", access = JsonProperty.Access.WRITE_ONLY)
    public void setExtractedContent(String extractedContent) {
        this.extractedContent = extractedContent;
    }

    @JsonProperty(value = ORGANISATION, access = JsonProperty.Access.READ_ONLY)
    public Set<String> getOrganisation() {
        return organisation;
    }

    @JsonProperty(value = "organisation", access = JsonProperty.Access.WRITE_ONLY)
    public void setOrganisation(Set<String> organisation) {
        this.organisation = organisation;
    }

    @JsonProperty(value = COUNTRY, access = JsonProperty.Access.READ_ONLY)
    public Set<String> getCountry() {
        return country;
    }

    @JsonProperty(value = "country", access = JsonProperty.Access.WRITE_ONLY)
    public void setCountry(Set<String> country) {
        this.country = country;
    }

    @JsonProperty(value = CITY, access = JsonProperty.Access.READ_ONLY)
    public Set<String> getCity() {
        return city;
    }

    @JsonProperty(value = "city", access = JsonProperty.Access.WRITE_ONLY)
    public void setCity(Set<String> city) {
        this.city = city;
    }

    @JsonProperty(value = PERSON, access = JsonProperty.Access.READ_ONLY)
    public Set<String> getPerson() {
        return person;
    }

    @JsonProperty(value = "person", access = JsonProperty.Access.WRITE_ONLY)
    public void setPerson(Set<String> person) {
        this.person = person;
    }

    @JsonProperty(value = STATE, access = JsonProperty.Access.READ_ONLY)
    public Set<String> getState() {
        return state;
    }

    @JsonProperty(value = "state", access = JsonProperty.Access.WRITE_ONLY)
    public void setState(Set<String> state) {
        this.state = state;
    }

    @JsonProperty(value = TAGS, access = JsonProperty.Access.READ_ONLY)
    public Set<String> getTags() {
        return tags;
    }

    @JsonProperty(value = "tags", access = JsonProperty.Access.WRITE_ONLY)
    public void setTags(Set<String> tags) {
        this.tags = tags;
    }

}
