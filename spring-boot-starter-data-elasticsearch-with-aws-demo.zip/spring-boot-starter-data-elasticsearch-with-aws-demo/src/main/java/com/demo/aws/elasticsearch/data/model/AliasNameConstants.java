package com.demo.aws.elasticsearch.data.model;

public final class AliasNameConstants {

    public static final String EXTRACTED_CONTENT = "ec";
    public static final String ORGANISATION = "org";
    public static final String PERSON = "pn";
    public static final String CONTENT_MANAGEMENT_ID = "cm_id";
    public static final String DOCUMENT_TYPE_ID = "dt_id";
    public static final String PROXY_SUBMITTER_ROLE_NAME = "p_sr_r_nm";
    public static final String COUNTRY = "ctry";
    public static final String CITY = "cty";
    public static final String PROCEEDING_NUMBER = "p_num";
    public static final String DOCUMENT_NUMBER = "d_num";
    public static final String DOCUMENT_TITLE = "d_title";
    public static final String DOCUMENT_TYPE_NAME = "d_type_nm";
    public static final String PROCEEDING_ARTIFACT_ID = "prd_at_id";
    public static final String PROCEEDING_ARTIFACT_NAME = "prd_at_nm";
    public static final String ARTIFACT_TYPE_CD = "art_ty_cd";
    public static final String PROCEEDING_TYPE_CD = "prd_type_cd";
    public static final String FILE_NAME = "f_nm";
    public static final String PAGE_COUNT = "p_cnt";
    public static final String CONFIDENTIALITY_IND = "c_in";
    public static final String AVAILABILITY_CODE = "avail_cd";
    public static final String FILING_TS = "fil_ts";
    public static final String LOADED_DATE = "ld_dt";
    public static final String LAST_MOD_USERID = "lst_md_uid";
    public static final String STATE = "st";
    public static final String TAGS = "tgs";
    public static final String LAST_MODIFIED_DATE = "date";
}
