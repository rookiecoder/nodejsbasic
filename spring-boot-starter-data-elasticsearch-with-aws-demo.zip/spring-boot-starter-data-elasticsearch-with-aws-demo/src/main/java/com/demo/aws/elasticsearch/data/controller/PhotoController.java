package com.demo.aws.elasticsearch.data.controller;

import com.demo.aws.elasticsearch.data.configuration.MappingConfig;
import com.demo.aws.elasticsearch.data.model.DataDocument;
import com.demo.aws.elasticsearch.data.model.PhotoDto;
import com.demo.aws.elasticsearch.data.service.EsService;
import com.demo.aws.elasticsearch.data.service.PhotoService;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.io.IOException;
import java.lang.annotation.Annotation;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@Slf4j
@RequestMapping("/photos")
public class PhotoController {

    @Autowired
    private PhotoService service = null;

    @Autowired
    private EsService esService = null;

    @Autowired
    private MappingConfig mappings = null;

    @PostMapping(consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<PhotoDto> createPhoto(@RequestBody PhotoDto document) {
        return new ResponseEntity<>(service.createPhoto(document), HttpStatus.CREATED);
    }

    @PutMapping(value = "/{id}", consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Void> updatePhoto(@PathVariable String id, @RequestBody PhotoDto document) {
        service.updatePhoto(id, document);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);
    }

    @GetMapping(value = "/{id}", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<PhotoDto> findById(@PathVariable String id) {
        return new ResponseEntity<>(service.findById(id), HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<List<PhotoDto>> findAll() {
        return new ResponseEntity<>(service.findAll(), HttpStatus.OK);
    }

    @GetMapping(value = "/search", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<PhotoDto>> search(@RequestParam(value = "key") String key, @RequestParam(value = "value") String value) {
        return new ResponseEntity<>(service.search(key, value), HttpStatus.OK);
    }

    @GetMapping(value = "/searchtags", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<PhotoDto>> search(@RequestParam(value = "key") String key ) {
        return new ResponseEntity<>(service.searchbyTags(key), HttpStatus.OK);
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deletePhoto(@PathVariable String id) {
        service.deletePhoto(id);
        return new ResponseEntity<>(HttpStatus.NO_CONTENT);

    }

    @GetMapping(value = "/documents", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<DataDocument>> searchDocuments() throws IOException {
        return new ResponseEntity<List<DataDocument>>(service.search(), HttpStatus.OK);
    }

    @PostMapping(value = "/search", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<DataDocument>> documentSearch(@RequestBody String payload) throws IOException {
        return new ResponseEntity<List<DataDocument>>(esService.searchQueryWithQueryBuilder(payload), HttpStatus.OK);
    }

    @PostMapping(value = "/create", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<DataDocument> create(@RequestBody DataDocument payload) throws IOException {
        return new ResponseEntity<DataDocument>(esService.create(payload), HttpStatus.OK);
    }

    @PostMapping(value = "/bulk", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<List<DataDocument>> create(@RequestBody List<DataDocument> payload) throws IOException {
        return new ResponseEntity<List<DataDocument>>(esService.bulkInsert(payload), HttpStatus.OK);
    }

    @GetMapping(value = "/mappings" , produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Map<String ,String>> mappings() throws NoSuchFieldException {


       return new ResponseEntity<Map<String ,String>>(mappings.getMappings(), HttpStatus.OK);

    }




}
