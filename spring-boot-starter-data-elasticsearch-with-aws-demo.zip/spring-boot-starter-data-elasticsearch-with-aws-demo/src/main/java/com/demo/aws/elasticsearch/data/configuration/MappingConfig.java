package com.demo.aws.elasticsearch.data.configuration;

import com.demo.aws.elasticsearch.data.model.AliasName;
import com.demo.aws.elasticsearch.data.model.DataDocument;
import org.springframework.stereotype.Component;

import java.lang.reflect.Field;
import java.util.HashMap;
import java.util.Map;

@Component
public class MappingConfig {

    public Map<String, String> getMappings() {

        Map<String, String> mappings = new HashMap<>();
        Field[] classMemberFields = DataDocument.class.getDeclaredFields();
        for(Field field : classMemberFields){
            AliasName property = field.getAnnotation(AliasName.class);
            if(property!=null){
                mappings.put(property.name(),field.getName());
            }

        }

        return mappings;
    }


}
