package com.demo.aws.elasticsearch.data.service;

import com.demo.aws.elasticsearch.data.Util;
import com.demo.aws.elasticsearch.data.configuration.MappingConfig;
import com.demo.aws.elasticsearch.data.model.DataDocument;
import com.fasterxml.jackson.core.JsonProcessingException;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.util.EntityUtils;
import org.elasticsearch.action.bulk.BulkRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.Request;
import org.elasticsearch.client.RequestOptions;
import org.elasticsearch.client.Response;
import org.elasticsearch.client.RestHighLevelClient;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.index.query.BoolQueryBuilder;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.List;

@Service
@Slf4j
public class EsService {

    @Value("${es.index}")
    private String esIndex;

    @Autowired
    @Qualifier("elasticsearchClient")
    RestHighLevelClient restHighLevelClient;

    @Autowired
    MappingConfig config;

    public List<DataDocument> search() throws IOException {
        Request request = new Request("POST", "/"+esIndex+"/_search");
        request.setJsonEntity("{\"query\":{\"match\" : {\"city\":\"bangalore\"}}}");
        Response response = restHighLevelClient.getLowLevelClient().performRequest(request);
        String responseBody = EntityUtils.toString(response.getEntity());
        return Util.transformResponse(responseBody);
    }

    public List<DataDocument> search(String payload) throws IOException {
        //String query = payload.get("query").toString();
        Request request = new Request("POST", "/"+esIndex+"/search");
        request.setJsonEntity(payload.replaceAll("[\\n\\t ]", ""));
        Response response = restHighLevelClient.getLowLevelClient().performRequest(request);
        String responseBody = EntityUtils.toString(response.getEntity());
        return Util.transformResponse(responseBody);
    }

    public List<DataDocument> searchQuery(String searchQuery) throws IOException {
        String query = Util.getJsonPropertyvalue(searchQuery.replaceAll("[\\n\\t ]", ""));
        QueryBuilder builder = QueryBuilders.wrapperQuery(query);
        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        searchSourceBuilder.query(builder);
        SearchRequest searchRequest = new SearchRequest(esIndex);
        searchRequest.source(searchSourceBuilder);
        SearchResponse searchResponse = restHighLevelClient.search(searchRequest, RequestOptions.DEFAULT);
        return Util.transformResponse(searchResponse);
    }

    public List<DataDocument> searchQueryWithQueryBuilder(String searchQuery) throws IOException {
        String query = Util.getJsonPropertyvalue(Util.removeAliases(searchQuery,config.getMappings()).replaceAll("[\\n\\t ]", ""));
        System.out.println(query);
//        BoolQueryBuilder first = QueryBuilders.boolQuery()
//                .must(QueryBuilders.matchQuery("city", "menlo park"))
//                .must(QueryBuilders.matchQuery("country", "us"));
//        BoolQueryBuilder filter = new BoolQueryBuilder()
//                .should(first);

        QueryBuilder builder = QueryBuilders.wrapperQuery(query);

        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        searchSourceBuilder.query(builder);
        SearchRequest searchRequest = new SearchRequest(esIndex);
        searchRequest.source(searchSourceBuilder);
        SearchResponse searchResponse = restHighLevelClient.search(searchRequest, RequestOptions.DEFAULT);
        return Util.transformResponse(searchResponse);
    }





    public DataDocument create(DataDocument payload) throws IOException {
        String json = Util.convert(payload);
        final IndexRequest indexRequest = new IndexRequest(esIndex,esIndex)
                .source(json, XContentType.JSON);
        IndexResponse response = restHighLevelClient.index(indexRequest,RequestOptions.DEFAULT);
        return payload;
    }

    public List<DataDocument> bulkInsert(List<DataDocument> payload) throws IOException {
        BulkRequest bulkRequest = new BulkRequest();
        payload.forEach(item -> {
            IndexRequest indexRequest = null;
            try {
                indexRequest = new IndexRequest(esIndex, esIndex).
                        source(Util.convert(item), XContentType.JSON);
            } catch (JsonProcessingException e) {
                log.error(e.getMessage(), e);
            }
            bulkRequest.add(indexRequest);
        });

        try {
            restHighLevelClient.bulk(bulkRequest, RequestOptions.DEFAULT);
        } catch (IOException e) {
            log.error(e.getMessage(), e);
        }
        return payload;
    }
}
