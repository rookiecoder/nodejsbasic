package com.demo.aws.elasticsearch.data.service;

import com.demo.aws.elasticsearch.data.Util;
import com.demo.aws.elasticsearch.data.document.PhotoDocument;
import com.demo.aws.elasticsearch.data.exception.ApplicationException;
import com.demo.aws.elasticsearch.data.model.DataDocument;
import com.demo.aws.elasticsearch.data.model.PhotoDto;
import com.demo.aws.elasticsearch.data.repository.PhotoRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.extern.slf4j.Slf4j;
import org.apache.http.HttpHost;
import org.apache.http.util.EntityUtils;
import org.elasticsearch.action.admin.indices.create.CreateIndexRequest;
import org.elasticsearch.action.index.IndexRequest;
import org.elasticsearch.action.index.IndexResponse;
import org.elasticsearch.action.search.SearchRequest;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.client.*;
import org.elasticsearch.common.xcontent.XContentType;
import org.elasticsearch.index.query.QueryBuilder;
import org.elasticsearch.index.query.QueryBuilders;
import org.elasticsearch.index.query.WrapperQueryBuilder;
import org.elasticsearch.search.SearchHit;
import org.elasticsearch.search.SearchHits;
import org.elasticsearch.search.builder.SearchSourceBuilder;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.*;

@Service
@Slf4j
public class PhotoService {

    @Value("${es.index}")
    private String esIndex;


    @Autowired
    private PhotoRepository photoRepository = null;



    public PhotoDto createPhoto(PhotoDto document) {
        PhotoDocument photoDocumentEntity = getPhotoDocument(document);
        PhotoDocument photoDocument = photoRepository.save(photoDocumentEntity);
        return getPhotoDto(photoDocument);
    }

    public PhotoDto findById(String id) {
        Optional<PhotoDocument> photoDocument = photoRepository.findById(id);
        if (photoDocument.isPresent()) {
            return getPhotoDto(photoDocument.get());
        }
        throw new ApplicationException(HttpStatus.NOT_FOUND);
    }

    private PhotoDto getPhotoDto(PhotoDocument photoDocument) {
        PhotoDto photoDto = new PhotoDto();
        BeanUtils.copyProperties(photoDocument, photoDto);
        return photoDto;
    }

    private PhotoDocument getPhotoDocument(PhotoDto photoDto) {
        PhotoDocument photoDocument = new PhotoDocument();
        BeanUtils.copyProperties(photoDto, photoDocument);
        photoDocument.setId(UUID.randomUUID().toString());
        return photoDocument;
    }

    public void updatePhoto(String id, PhotoDto document) {
        findById(id);
        PhotoDocument photoDocumentEntity = getPhotoDocument(document);
        photoRepository.save(photoDocumentEntity);
    }

    public List<PhotoDto> findAll() {
        Iterable<PhotoDocument> photoDocuments = photoRepository.findAll();
        return getPhotoDtos(photoDocuments);
    }

    public List<PhotoDto> search(String key, String value) {
        List<PhotoDocument> photoDocuments = photoRepository.findByUsingQuery(key, value);
        if (photoDocuments.isEmpty()) {
            throw new ApplicationException(HttpStatus.NOT_FOUND);
        }
        return getPhotoDtos(photoDocuments);
    }

    public List<PhotoDto> searchbyTags(String key) {
        Page<PhotoDocument> photoDocuments = photoRepository.findByTagUsingDeclaredQuery(key, PageRequest.of(0, 10));
        if (photoDocuments.isEmpty()) {
            throw new ApplicationException(HttpStatus.NOT_FOUND);
        }
        return getPhotoDtos(photoDocuments);
    }

    private List<PhotoDto> getPhotoDtos(Iterable<PhotoDocument> photoDocuments) {
        List<PhotoDto> photoDtoList = new ArrayList<>();
        photoDocuments.forEach(e -> photoDtoList.add(getPhotoDto(e)));
        return photoDtoList;
    }

    public void deletePhoto(String id) {
        findById(id);
        photoRepository.deleteById(id);
    }

    RestHighLevelClient restHighLevelClient = new RestHighLevelClient(RestClient.builder(new HttpHost("localhost", 9200, "http")));

    public List<DataDocument> search() throws IOException {
        Request request = new Request("POST", "/"+esIndex+"/_search");
        request.setJsonEntity("{\"query\":{\"match\" : {\"city\":\"bangalore\"}}}");
        Response response = restHighLevelClient.getLowLevelClient().performRequest(request);
        String responseBody = EntityUtils.toString(response.getEntity());
        return Util.transformResponse(responseBody);
    }

    public List<DataDocument> search(String payload) throws IOException {
        //String query = payload.get("query").toString();
        Request request = new Request("POST", "/"+esIndex+"/search");
        request.setJsonEntity(payload.replaceAll("[\\n\\t ]", ""));
        Response response = restHighLevelClient.getLowLevelClient().performRequest(request);
        String responseBody = EntityUtils.toString(response.getEntity());
        return Util.transformResponse(responseBody);
    }

    public List<DataDocument> searchQuery(String searchQuery) throws IOException {
        String query = Util.getJsonPropertyvalue(searchQuery.replaceAll("[\\n\\t ]", ""));
        QueryBuilder builder = QueryBuilders.wrapperQuery(query);
        SearchSourceBuilder searchSourceBuilder = new SearchSourceBuilder();
        searchSourceBuilder.query(builder);
        SearchRequest searchRequest = new SearchRequest(esIndex);
        searchRequest.source(searchSourceBuilder);
        SearchResponse searchResponse = restHighLevelClient.search(searchRequest, RequestOptions.DEFAULT);
        return Util.transformResponse(searchResponse);
    }

    public DataDocument create(DataDocument payload) throws IOException {
        String json = Util.convert(payload);
        final IndexRequest indexRequest = new IndexRequest(esIndex,esIndex)
                .source(json, XContentType.JSON);
        IndexResponse response = restHighLevelClient.index(indexRequest,RequestOptions.DEFAULT);
        return payload;
    }

}
