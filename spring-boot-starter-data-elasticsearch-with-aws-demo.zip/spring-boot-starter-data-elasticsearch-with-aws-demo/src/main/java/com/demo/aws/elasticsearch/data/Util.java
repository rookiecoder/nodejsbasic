package com.demo.aws.elasticsearch.data;

import com.demo.aws.elasticsearch.data.model.DataDocument;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.search.SearchHits;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

public class Util {
    static ObjectMapper objectMapper = new ObjectMapper();

    public static List<DataDocument> transformResponse(String responseBody) throws JsonProcessingException {
        List<DataDocument> documents = new ArrayList<>();
        JsonNode actualObj = objectMapper.readTree(responseBody);
        JsonNode hitParents = actualObj.get("hits");
        JsonNode hitsArrays = hitParents.get("hits");
        if(hitsArrays.isArray()){
            for(JsonNode hitObject : hitsArrays) {
                DataDocument dataDocument = objectMapper.convertValue(hitObject.get("_source"), DataDocument.class);
                documents.add(dataDocument);
            }
        }
        return documents;
    }

    public static List<DataDocument> transformResponse(SearchResponse searchResponse) throws JsonProcessingException {
        SearchHits hits = searchResponse.getHits();
        List<DataDocument> documents = new ArrayList<>();
        Arrays.stream(hits.getHits()).forEach(hit -> {
            String source = hit.getSourceAsString();
            DataDocument document = null;
            try {
                document = objectMapper.readValue(source, DataDocument.class);
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
            documents.add(document);
        });
        return documents;
    }

    public static String convert(DataDocument data) throws JsonProcessingException {
      return objectMapper.writeValueAsString(data);
    }

    public static String getJsonPropertyvalue(String json) throws JsonProcessingException {
        return objectMapper.readTree(json).get("query").toString();
    }
}
