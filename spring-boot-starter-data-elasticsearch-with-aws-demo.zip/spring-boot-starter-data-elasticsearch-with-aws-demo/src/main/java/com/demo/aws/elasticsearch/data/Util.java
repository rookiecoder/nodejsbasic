package com.demo.aws.elasticsearch.data;

import com.demo.aws.elasticsearch.data.model.DataDocument;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import org.elasticsearch.action.search.SearchResponse;
import org.elasticsearch.search.SearchHits;

import java.util.*;

public class Util {
    static ObjectMapper objectMapper = new ObjectMapper();

    public static List<DataDocument> transformResponse(String responseBody) throws JsonProcessingException {
        List<DataDocument> documents = new ArrayList<>();
        JsonNode actualObj = objectMapper.readTree(responseBody);
        JsonNode hitParents = actualObj.get("hits");
        JsonNode hitsArrays = hitParents.get("hits");
        if(hitsArrays.isArray()){
            for(JsonNode hitObject : hitsArrays) {
                DataDocument dataDocument = objectMapper.convertValue(hitObject.get("_source"), DataDocument.class);
                documents.add(dataDocument);
            }
        }
        return documents;
    }

    public static List<DataDocument> transformResponse(SearchResponse searchResponse) throws JsonProcessingException {
        SearchHits hits = searchResponse.getHits();
        List<DataDocument> documents = new ArrayList<>();
        Arrays.stream(hits.getHits()).forEach(hit -> {
            String source = hit.getSourceAsString();
            DataDocument document = null;
            try {
                document = objectMapper.readValue(source, DataDocument.class);
            } catch (JsonProcessingException e) {
                e.printStackTrace();
            }
            documents.add(document);
        });
        return documents;
    }

    public static String convert(DataDocument data) throws JsonProcessingException {
      return objectMapper.writeValueAsString(data);
    }

    public static String getJsonPropertyvalue(String json) throws JsonProcessingException {
        return objectMapper.readTree(json).get("query").toString();
    }

    public static String removeAliases(String json,Map<String, String> keys) throws JsonProcessingException {
        JsonNode parent = objectMapper.readTree(json);
        System.out.println(objectMapper.writeValueAsString(parent));
        for (Map.Entry<String,String> key : keys.entrySet()) {
            List<JsonNode> children = parent.findParents(key.getKey());
            if(children == null || children.size()==0){
                continue   ;
            }

            for(JsonNode child : children){
                //ObjectNode objectNode = ((ObjectNode)child).findParent(key.getKey());
                //((ObjectNode) child).fin
                ((ObjectNode) child).put(key.getValue(), child.get(key.getKey()));
                ((ObjectNode) child).remove(key.getKey());
                System.out.printf("Key %s exists? %s --> value=%s%n", key, child != null,
                        child == null ? null : key.getKey());

            }


        }
        return objectMapper.writeValueAsString(parent);
    }

}
