# spring-boot-starter-data-elasticsearch-with-aws
Sample Project to demonstrate the integration of Springboot ElasticSearch Data with Amazon ElasticSearch Service
