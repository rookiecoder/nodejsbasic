package org.gov.uspto.controller;

import edu.stanford.nlp.ling.CoreAnnotations;
import edu.stanford.nlp.ling.CoreLabel;
import edu.stanford.nlp.pipeline.CoreDocument;
import edu.stanford.nlp.pipeline.CoreEntityMention;
import edu.stanford.nlp.pipeline.StanfordCoreNLP;
import org.apache.commons.text.WordUtils;
import org.gov.uspto.core.NERExtractor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@RestController
@RequestMapping(value = "/api/v1")
public class NERController {

    @Autowired
    private NERExtractor stanfordNERExtractor;

    @PostMapping
    @RequestMapping(value = "/ner")
    public Map<String, String> ner(@RequestBody final String input) throws ExecutionException, InterruptedException {

        List<String> list = new ArrayList<>();
        list.add(input);
        list.add("Raghu Venkatesh");
        list.add("France");

        //CompletableFuture<Map<String, String>> future = nreExtractor.submitExtract(input);

        List<CompletableFuture<Map<String,String>>>  futures =   stanfordNERExtractor.submitExtractEntities(list);

        Map<String,String> mapping = new HashMap<String, String>();
        for(CompletableFuture<Map<String,String>> future : futures){
            mapping.putAll(future.get());
        }

        return mapping;
    }
}
