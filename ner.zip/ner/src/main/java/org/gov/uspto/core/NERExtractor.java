package org.gov.uspto.core;

import edu.stanford.nlp.pipeline.CoreDocument;
import edu.stanford.nlp.pipeline.CoreEntityMention;
import edu.stanford.nlp.pipeline.StanfordCoreNLP;
import org.apache.commons.text.WordUtils;
import org.gov.uspto.config.Config;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.stream.IntStream;

@Component("stanfordNERExtractor")
public class NERExtractor implements Extractor{

    @Autowired
    private StanfordCoreNLP stanfordCoreNLP;

    @Autowired
    private Config config;

    public Map<String ,String>  extractEntities(String input){
        CoreDocument coreDocument = new CoreDocument(WordUtils.capitalize(input));
        stanfordCoreNLP.annotate(coreDocument);
        Map<String ,String> mapping = new HashMap<>();
        System.out.println("Running extract... thread id: " + Thread.currentThread().getId());

        for (CoreEntityMention em : coreDocument.entityMentions()) {
            if (!config.getEntities().contains(em.entityType()) || !config.getEntitiesFilter().contains(em.text()))
                continue;
            mapping.put(em.text(),em.entityType());
        }
        return mapping;
    }

    public CompletableFuture<Map<String, String>> submitExtractEntities(String input) {
        CompletableFuture<Map<String, String>> future = CompletableFuture.supplyAsync(() -> {
                System.out.println("Running extract... thread id: " + Thread.currentThread().getId());
            return extractEntities(input);
        });
        return future;
    }

    public List<CompletableFuture<Map<String, String>>> submitExtractEntities(List<String> inputs){
        List<CompletableFuture<Map<String, String>>> futures = new ArrayList<>();
        int size = inputs.size();

        IntStream.range(0, size).forEach(num -> {
            futures.add(CompletableFuture.supplyAsync(() -> extractEntities(inputs.get(num))));
        });

        CompletableFuture.allOf(futures.toArray(new CompletableFuture[0]))
                .thenRunAsync(() -> System.out.println("done"));
        return futures;
    }

}
