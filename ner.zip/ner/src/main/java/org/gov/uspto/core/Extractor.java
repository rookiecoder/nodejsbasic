package org.gov.uspto.core;

import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;

public interface Extractor {
     Map<String ,String> extractEntities(String input);
     CompletableFuture<Map<String, String>> submitExtractEntities(String input);
     List<CompletableFuture<Map<String, String>>> submitExtractEntities(List<String> inputs);
}
