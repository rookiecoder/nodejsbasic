# ner-application
Named Entity Recognizer (NER) with Spring Boot

API :
  extractEntities  - searches for the entities with value in 

