# ner-application
Named Entity Recognizer (NER) with Spring Boot


