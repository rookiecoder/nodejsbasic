package org.gov.uspto.controller;

import edu.stanford.nlp.ling.CoreAnnotations;
import edu.stanford.nlp.ling.CoreLabel;
import edu.stanford.nlp.pipeline.CoreDocument;
import edu.stanford.nlp.pipeline.CoreEntityMention;
import edu.stanford.nlp.pipeline.StanfordCoreNLP;
import org.apache.commons.text.WordUtils;
import org.gov.uspto.core.NERExtractor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;

@RestController
@RequestMapping(value = "/api/v1")
public class NERController {

    @Autowired
    private NERExtractor nreExtractor;

    @PostMapping
    @RequestMapping(value = "/ner")
    public Map<String, String> ner(@RequestBody final String input) throws ExecutionException, InterruptedException {
        CompletableFuture<Map<String, String>> future = nreExtractor.submitExtract(input);
        CompletableFuture<Map<String, String>> future1 = nreExtractor.submitExtract(input);
        while (!future.isDone() && future1.isDone()) {

        }
        return future.get();
    }
}
