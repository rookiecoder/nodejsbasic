package org.gov.uspto.core;

import edu.stanford.nlp.ling.CoreLabel;
import edu.stanford.nlp.pipeline.CoreDocument;
import edu.stanford.nlp.pipeline.CoreEntityMention;
import edu.stanford.nlp.pipeline.StanfordCoreNLP;
import org.apache.commons.text.WordUtils;
import org.gov.uspto.config.Config;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.stream.Collectors;

@Component
public class NERExtractor {

    @Autowired
    private StanfordCoreNLP stanfordCoreNLP;

    @Autowired
    private Config config;

    public Map<String ,String>  extract(String input){
        CoreDocument coreDocument = new CoreDocument(WordUtils.capitalize(input));
        stanfordCoreNLP.annotate(coreDocument);
        Map<String ,String> mapping = new HashMap<>();
        for (CoreEntityMention em : coreDocument.entityMentions()) {
            if (!config.getEntities().contains(em.entityType()) || !config.getEntitiesFilter().contains(em.text()))
                continue;
            mapping.put(em.text(),em.entityType());
        }
        return mapping;
    }

    public CompletableFuture<Map<String, String>> submitExtract(String input) {
        CompletableFuture<Map<String, String>> future = CompletableFuture.supplyAsync(() -> {
                System.out.println("Running extract... thread id: " + Thread.currentThread().getId());
            return extract(input);
        });
        return future;
    }
}
